import { configureStore } from "@reduxjs/toolkit";

import analyseChartReducer from "../features/analyseChart/analyseChartSlice";
import evalFailuresReducer from "../features/executionFailure/evalFailuresSlice";
import evalRunReducer from "../pages/dashboard/evalRunSlice";
import evalReportReducer from "../pages/evalReport/evalReportSlice";

import { apiSlice } from "./apiSlice";
import appReducer from "./appSlice";

export const setupStore = (preloadedState) => {
  return configureStore({
    reducer: {
      [apiSlice.reducerPath]: apiSlice.reducer,
      analyseChart: analyseChartReducer,
      evalReport: evalReportReducer,
      evalFailures: evalFailuresReducer,
      evalResults: evalRunReducer,
      app: appReducer,
    },
    preloadedState,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({}).concat(apiSlice.middleware),
  });
};
