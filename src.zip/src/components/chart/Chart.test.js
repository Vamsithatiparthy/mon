import React from "react";
import { screen } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { transformEvalChartsRespnse } from "../../features/analyseChart/transformApiResponse";
import { renderWithProviders } from "../../test/test-utils";
import analyseChartData from "../../utils/mockdata/analyseChart";

import Chart from "./Chart";

const eval_charts = transformEvalChartsRespnse(analyseChartData.eval_results);

describe("Renders Chart Component correctly", () => {
  test("Renders Chart Component correctly", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[2]} />
      </Toolkit>
    );
    expect(screen.getByTestId(/render-chart/i)).toBeInTheDocument();
  });
});

describe("Renders mad_qreg_timeseriesanalysis details correctly", () => {
  test("Renders mad_qreg_timeseriesanalysis chart details correctly", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[2]} />
      </Toolkit>
    );
    // rule name is there
    expect(
      screen.getAllByTestId(
        /mad_qreg_timeseriesanalysis-TIME_SERIES of L4_PAT_PROV_ATTRIB/i
      )[0]
    ).toBeInTheDocument();
    // entity details is there
    expect(
      screen.getAllByTestId(
        /mad_qreg_timeseriesanalysis-TEMP_OADW_L4_PAT_PROV_ATTRIB-test7/i
      )[0]
    ).toBeInTheDocument();
    // partition_granularity is there
    expect(
      screen.getAllByTestId(/mad_qreg_timeseriesanalysis-4343/i)[0]
    ).toBeInTheDocument();
    // severity is there
    expect(
      screen.getAllByTestId(
        /mad_qreg_timeseriesanalysis-0.00309754093179088/i
      )[0]
    ).toBeInTheDocument();
  });
  test("Renders mad_qreg_timeseriesanalysis plotly chart", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[2]} />
      </Toolkit>
    );
    expect(
      screen.getAllByTestId(/mad_qreg_timeseriesanalysis_chart/i)[0]
    ).toBeInTheDocument();
  });
  test("Renders mad_qreg_timeseriesanalysis table", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[2]} />
      </Toolkit>
    );
    expect(
      screen.getAllByTestId(/mad_qreg_timeseriesanalysis_chart_table/i)[0]
    ).toBeInTheDocument();
  });
});

describe("Renders rateanalysis details correctly", () => {
  test("Renders rateanalysis chart details correctly", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[1]} />
      </Toolkit>
    );
    // rule name is there
    expect(
      screen.getAllByTestId(/rateanalysis-Rate of L4_PATV_ATTRIB/i)[0]
    ).toBeInTheDocument();
    // entity details is there
    expect(
      screen.getAllByTestId(/rateanalysis-TEMP_OADW_L4_PAT_PROV-test7/i)[0]
    ).toBeInTheDocument();
    // partition_granularity is there
    expect(screen.getAllByTestId(/rateanalysis-4343/i)[0]).toBeInTheDocument();
    // severity is there
    expect(
      screen.getAllByTestId(/rateanalysis-0.00309754093179088/i)[0]
    ).toBeInTheDocument();
  });
  test("Renders rateanalysis plotly chart", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[1]} />
      </Toolkit>
    );
    expect(screen.getAllByTestId(/rateanalysis_chart/i)[0]).toBeInTheDocument();
  });
  test("Renders rateanalysis table", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[1]} />
      </Toolkit>
    );
    expect(screen.getAllByTestId(/rateanalysis_table/i)[0]).toBeInTheDocument();
  });
});

describe("Renders numdistanalysis details correctly", () => {
  test("Renders numdistanalysis chart details correctly", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[0]} />
      </Toolkit>
    );
    // rule name is there
    expect(
      screen.getAllByTestId(/numdistanalysis-NUMDIST of L4_PAT_PROV_ATTRIB/i)[0]
    ).toBeInTheDocument();
    // entity details is there
    expect(
      screen.getAllByTestId(
        /numdistanalysis-TEMP_OADW_L2_PAT_PROV_ATTRIB-test7/i
      )[0]
    ).toBeInTheDocument();
    // partition_granularity is there
    expect(
      screen.getAllByTestId(/numdistanalysis-4343/i)[0]
    ).toBeInTheDocument();
    // severity is there
    expect(
      screen.getAllByTestId(/numdistanalysis-0.00309754093179088/i)[0]
    ).toBeInTheDocument();
  });
  test("Renders numdistanalysis plotly chart", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[0]} />
      </Toolkit>
    );
    expect(
      screen.getAllByTestId(/numdistanalysis_chart/i)[0]
    ).toBeInTheDocument();
  });
  test("Renders numdistanalysis table", async () => {
    renderWithProviders(
      <Toolkit>
        <Chart chartData={eval_charts[0]} />
      </Toolkit>
    );
    expect(
      screen.getAllByTestId(/numdistanalysis_table/i)[0]
    ).toBeInTheDocument();
  });
});
