import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  saveChangesEnabled: false,
  enableNextStep: false,
  enablePrevStep: false,
  snackBar: {
    show: false,
    message: "",
    variant: "success",
  },
};

const evalReportSlice = createSlice({
  name: "evalReport",
  initialState,
  reducers: {
    toggleSaveChanges(state, action) {
      state.saveChangesEnabled = action.payload;
    },
    showAlert(state, action) {
      state.snackBar.show = action.payload.show;
      state.snackBar.message = action.payload.message;
      state.snackBar.variant = action.payload.variant;
    },
    updateStepButtons(state, action) {
      state.enableNextStep = action.payload.enableNextStep;
      state.enablePrevStep = action.payload.enablePrevStep;
    },
  },
});

export const { toggleSaveChanges, showAlert, updateStepButtons } =
  evalReportSlice.actions;
export default evalReportSlice.reducer;
