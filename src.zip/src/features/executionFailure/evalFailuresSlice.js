import {
  createEntityAdapter,
  createSelector,
  createSlice,
} from "@reduxjs/toolkit";

import { containsString, sort } from "../../utils/common";

const evalFailuresAdapter = createEntityAdapter();
const initialState = evalFailuresAdapter.getInitialState({
  actionBtnHeight: 0,
  filters: {
    category: [],
    column: [],
    model: [],
    reason: "",
    hideRecurring: false,
  },
  tableHeader: {
    sortColumnKey: "is_recurring",
    sortDirection: -1,
  },
  reasonTooltipVisbility: null,
});

const evalFailuresSlice = createSlice({
  name: "evalFailures",
  initialState,
  reducers: {
    setEvalFailures(state, action) {
      evalFailuresAdapter.setAll(state, action.payload);
    },
    updateOneEvalFailure(state, action) {
      evalFailuresAdapter.updateOne(state, action.payload);
    },
    resetUpdateFlageOnEvalFailures(state) {
      Object.values(state.entities).forEach((evalFailure) => {
        evalFailure.updated = false;
      });
    },
    setActionBtnHeight(state, action) {
      state.actionBtnHeight = action.payload;
    },
    setReasonTooltipVisbility(state, action) {
      state.reasonTooltipVisbility = action.payload;
    },
    updateFilters(state, action) {
      state.filters = {
        ...state.filters,
        category: action.payload.category,
        column: action.payload.column,
        model: action.payload.model,
        reason: action.payload.reason,
        hideRecurring: action.payload.hideRecurring,
      };
    },
    updateTableHeader(state, action) {
      state.tableHeader = {
        ...state.tableHeader,
        sortColumnKey: action.payload.sortColumnKey,
        sortDirection: action.payload.sortDirection,
      };
    },
  },
});

export const {
  setEvalFailures,
  setActionBtnHeight,
  updateOneEvalFailure,
  setReasonTooltipVisbility,
  resetUpdateFlageOnEvalFailures,
  updateFilters,
  updateTableHeader,
} = evalFailuresSlice.actions;
export default evalFailuresSlice.reducer;

export const { selectAll: selectEvalFailures } =
  evalFailuresAdapter.getSelectors((state) => state.evalFailures);

export const selectUpdatedEvalFailures = createSelector(
  selectEvalFailures,
  (evalFailures) =>
    evalFailures.filter((evalFailure) => evalFailure["updated"] == true)
);

export const selectFilteredEvalFailures = createSelector(
  [selectEvalFailures, (state) => state.evalFailures.filters],
  (evalFailures, filters) => {
    return evalFailures.filter((element) => {
      const { category, column, model, reason, hideRecurring } = filters;
      const categoryFilter =
        category.length != 0
          ? containsString([...category], element["category"])
          : true;
      const modelFilter =
        model.length != 0 ? containsString([...model], element["model"]) : true;
      const reasonFilter =
        reason != ""
          ? element["reason"]
              .toString()
              .toLowerCase()
              .includes(reason?.toString().toLowerCase().trim())
          : true;
      const columnFilter =
        column.length != 0
          ? containsString([...column], element["column"])
          : true;
      const hideRecurringFailures = !hideRecurring
        ? true
        : !element["is_recurring"];

      return (
        categoryFilter &&
        modelFilter &&
        reasonFilter &&
        columnFilter &&
        hideRecurringFailures
      );
    });
  }
);

export const selectTableDataEvalFailures = createSelector(
  [selectFilteredEvalFailures, (state) => state.evalFailures.tableHeader],
  (evalFailures, tableHeader) => {
    return sort(
      evalFailures,
      tableHeader.sortColumnKey,
      tableHeader.sortDirection
    );
  }
);
