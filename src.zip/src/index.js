import React from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { createTheme } from "@abyss/web/tools/theme";
import { ThemeProvider } from "@abyss/web/ui/ThemeProvider";
import { ToastProvider } from "@abyss/web/ui/Toast";
import { Toolkit } from "@uitk/react";

import "@uitk/themes/optum/fonts.css";

import { setupStore } from "./app/store";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
// import makeServer from "./server";

const container = document.getElementById("root");
const root = createRoot(container);
const store = setupStore();

const theme = createTheme("optum", {
  css: { ".abyss-theme-provider-root": null },
});

// makeServer();

root.render(
  <Provider store={store}>
    <ThemeProvider theme={theme}>
      <Toolkit grid>
        <ToastProvider position="top-center" limit={2} />
        <App />
      </Toolkit>
    </ThemeProvider>
  </Provider>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
