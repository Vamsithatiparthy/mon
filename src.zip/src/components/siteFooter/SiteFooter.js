import { useSelector } from "react-redux";
import { Footer } from "@uitk/react";

function SiteFooter() {
  // created site footer component to handle footer width when filter is opened in Analyse chart page
  const { isFiltersOpen } = useSelector((state) => state.analyseChart);

  return (
    <div className={`${isFiltersOpen ? "ml-[24%]" : ""} footer`}>
      <Footer />
    </div>
  );
}

export default SiteFooter;
