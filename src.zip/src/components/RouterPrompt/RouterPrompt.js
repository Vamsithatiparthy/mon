import React, { useEffect, useRef, useState } from "react";
import { Button } from "@uitk/react";
import { WarningFilled } from "@uitk/react-icons";
import PropTypes from "prop-types";

import { constant } from "../../utils/constants";
function RouterPrompt({ when, title, content, variant, history }) {
  const [showPrompt, setShowPrompt] = useState(false);
  const [currentPath, setCurrentPath] = useState("");
  const [backgroundColor] = useState({
    warning: "#F5B700",
  });
  const [icon] = useState({
    warning: <WarningFilled className="model-icon" />,
  });

  const unblockRef = useRef();
  const showPromptRef = useRef();
  showPromptRef.current = when;

  function handleShowModal() {
    setShowPrompt(true);
  }

  function onCancel() {
    setShowPrompt(false);
  }

  useEffect(() => {
    unblockRef.current = history.block((location) => {
      if (when) {
        setCurrentPath(location.pathname);
        handleShowModal();
        return false;
      }
      return true;
    });
  }, [when]);

  function handleConfirm() {
    if (unblockRef) {
      unblockRef.current();
    }
    setShowPrompt(false);
    history.push(currentPath);
  }

  window.addEventListener("beforeunload", (event) => {
    if (showPromptRef.current) {
      event.preventDefault();
      event.returnValue = "";
    }
  });

  return showPrompt ? (
    <div id="myModal" className="modal" data-testid="router-prompt">
      <div className="modal-content">
        <div
          className="modal-header"
          style={{ background: backgroundColor[variant] }}
        >
          <h4>
            {icon[variant]}
            {title}
          </h4>
        </div>

        <div className="modal-body">
          <p>{content}</p>
          <div className="modal-footer">
            <Button variant="ghost" className="modal-btn" onClick={onCancel}>
              {constant.STAY_ON_PAGE}
            </Button>
            <Button variant="ghost" onClick={handleConfirm}>
              {constant.LEAVE_PAGE}
            </Button>
          </div>
        </div>
      </div>
    </div>
  ) : null;
}
RouterPrompt.propTypes = {
  when: PropTypes.bool,
  title: PropTypes.string,
  content: PropTypes.string,
  variant: PropTypes.string,
  history: PropTypes.object,
};

export default RouterPrompt;
