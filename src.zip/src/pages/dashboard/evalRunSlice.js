import {
  createEntityAdapter,
  createSelector,
  createSlice,
} from "@reduxjs/toolkit";
import moment from "moment";

import { reportStatus } from "../../utils/constants";
const evalResultsAdapter = createEntityAdapter();

const initialState = evalResultsAdapter.getInitialState({
  unStructuredEvalResults: [],
  filters: {
    clientid: "",
    version: "",
    env: "",
    level: "",
    fromdate: moment(new Date().setMonth(new Date().getMonth() - 6)).format(
      "YYYY-MM-DD"
    ),
    todate: moment(new Date()).format("YYYY-MM-DD"),
    readytoreview: true,
    approved: false,
    rejected: false,
    reset: false,
    reportStatusCount: {
      readytoreview: 0,
      approved: 0,
      rejected: 0,
    },
  },
});

let reportStatusCount;

const evalRunReducer = createSlice({
  name: "evalResults",
  initialState,
  reducers: {
    setEvalResults(state, action) {
      evalResultsAdapter.setAll(state, action.payload);
    },
    setUnstructuredEvalResults(state, action) {
      state.unStructuredEvalResults = action.payload;
    },
    updateFilters(state, action) {
      state.filters = {
        ...state.filters,
        clientid: action.payload.clientid,
        env: action.payload.env,
        version: action.payload.version,
        level: action.payload.level,
        fromdate: action.payload.fromdate,
        todate: action.payload.todate,
        readytoreview: action.payload.readytoreview,
        approved: action.payload.approved,
        rejected: action.payload.rejected,
        reset: action.payload.reset,
      };
    },
  },
});

export const { selectAll: selectEvalResults } = evalResultsAdapter.getSelectors(
  (state) => {
    return state.evalResults;
  }
);

const getReportStatusFilter = (
  report_status,
  approved,
  rejected,
  readytoreview
) => {
  return (
    (report_status === reportStatus.APPROVED && approved) ||
    (report_status === reportStatus.REJECTED && rejected) ||
    (report_status === null && readytoreview)
  );
};

export const selectFilteredEvalResult = createSelector(
  [selectEvalResults, (state) => state.evalResults.filters],
  (evalResults, filters) => {
    let filteredResults = [];
    let initialReportStatusCount = {
      readytoreview: 0,
      approved: 0,
      rejected: 0,
    };
    evalResults.forEach((element) => {
      const {
        clientid,
        env,
        version,
        level,
        approved,
        rejected,
        readytoreview,
        fromdate,
        todate,
      } = filters;
      const startDate = new Date(fromdate);
      startDate.setHours(0);
      startDate.setMinutes(0);
      startDate.setSeconds(0);
      const endDate = new Date(todate);
      endDate.setHours(23);
      endDate.setMinutes(59);
      endDate.setSeconds(59);
      const clientidFilter =
        clientid != ""
          ? element["clientid"]
              ?.toString()
              .toLowerCase()
              .includes(clientid?.toLowerCase().trim())
          : true;

      const versionFilter =
        version != ""
          ? element["version"]
              ?.toString()
              .toLowerCase()
              .includes(version?.toString().toLowerCase().trim())
          : true;

      const envFilter =
        env != ""
          ? element["env"]
              ?.toString()
              .toLowerCase()
              .includes(env?.toString().toLowerCase().trim())
          : true;

      if (clientidFilter && versionFilter && envFilter) {
        const level_data = element;

        const date = new Date(level_data["completed_date"]);
        date.setHours(date.getHours() + 5);
        date.setMinutes(date.getMinutes() + 30);

        if (startDate <= date && date <= endDate) {
          const levelFilter =
            level != ""
              ? level_data["level"]
                  ?.toString()
                  .toLowerCase()
                  .includes(level?.toLowerCase().trim())
              : true;
          const reportStatusFilter = getReportStatusFilter(
            level_data["review_details"]["review_outcome"],
            approved,
            rejected,
            readytoreview
          );

          if (levelFilter) {
            if (level_data["review_details"]["review_outcome"] === null) {
              initialReportStatusCount["readytoreview"] =
                initialReportStatusCount["readytoreview"] + 1;
            } else {
              initialReportStatusCount[
                level_data["review_details"]["review_outcome"]
              ] =
                initialReportStatusCount[
                  level_data["review_details"]["review_outcome"]
                ] + 1;
            }
          }

          if (levelFilter && reportStatusFilter) {
            filteredResults.push(level_data);
          }
        }
      }
    });
    reportStatusCount = { ...initialReportStatusCount };
    return filteredResults;
  }
);

export const getReportStatusCount = () => {
  return reportStatusCount;
};

export const { setEvalResults, updateFilters, setUnstructuredEvalResults } =
  evalRunReducer.actions;

export default evalRunReducer.reducer;
