import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import VisibilitySensor from "react-visibility-sensor";
import PropTypes from "prop-types";

import AnalyseChartFilter from "../../components/analyseChartFilter/AnalyseChartFilter.js";

import { setPage, setPageLimit, updateFilters } from "./analyseChartSlice.js";
import ChartList from "./ChartList.js";
function AnalyseChart({ evalId }) {
  /* Below code can be use for referenced if we require root filters api */

  // const { data: rootFilters } = useGetRootFiltersQuery(
  //   "app-20230720113010-0000_20230720124741"
  // );
  // const rootFilterStateName = rootFilters?.stateName;

  const { isFiltersOpen } = useSelector((state) => state.analyseChart);

  const [isVisible, setIsVisible] = useState(true);
  const dispatch = useDispatch();

  /* Below code can be use for referenced if we require root filters api */

  // useEffect(() => {
  //   if (rootFilterStateName)
  //     setAnalyseChartFilter((prevState) => ({
  //       ...prevState,
  //       [rootFilterStateName]: [rootFilters?.options[0].value],
  //     }));
  // }, [rootFilters]);

  useEffect(() => {
    return () => {
      const newFilters = {
        modelName: [],
        columnName: [],
        ruleName: [],
        flaggedStatus: [],
        includeSeverity: true,
        includeCore: false,
        rule: [],
      };
      dispatch(setPage(1));
      dispatch(setPageLimit(10));
      dispatch(updateFilters(newFilters));
    };
  }, []);

  return (
    <>
      <VisibilitySensor
        offset={{ top: 148 }}
        onChange={(visible) => setIsVisible(visible)}
      >
        {/* below element is a dummy element to make visibility sensor work */}
        {() => <span className="text-white">Dummy Element</span>}
      </VisibilitySensor>
      <div
        data-testid="analyse-chart-page"
        className="mt-4 pl-8 pr-12 w-full flex overflow-y-hidden relative"
      >
        <div
          className={`${isFiltersOpen ? "w-[24%]" : "w-[72px] h-[62px]"} ${
            !isVisible
              ? `fixed top-[179px] bg-[#fbf9f4] z-[10001] overflow-y-scroll ${
                  isFiltersOpen ? "w-[calc(24%-40px)] h-[calc(100%-180px)]" : ""
                }`
              : "relative"
          } bg-[#fbf9f4]`}
        >
          <AnalyseChartFilter evalId={evalId} />
        </div>
        <div
          className={`${isFiltersOpen ? "w-[76%]" : "w-full"} ${
            !isVisible && isFiltersOpen ? "ml-[24%]" : ``
          } ${
            !isVisible && !isFiltersOpen ? "ml-[74px]" : ``
          } border-solid border-t-[4px] border-[#FBFBFB] left-0 p-8 pt-0 overflow-y-scroll`}
        >
          <ChartList evalId={evalId} />
        </div>
      </div>
    </>
  );
}

AnalyseChart.propTypes = {
  evalId: PropTypes.string,
};
export default AnalyseChart;
