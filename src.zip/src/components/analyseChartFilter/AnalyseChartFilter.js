import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import VisibilitySensor from "react-visibility-sensor";
import { SelectInputMulti } from "@abyss/web/ui/SelectInputMulti";
import { Button, Checkbox, FormControl } from "@uitk/react";
import { Contract, Expand, Filter } from "@uitk/react-icons";
import PropTypes from "prop-types";

import { useGetEvalResultsMutation } from "../../features/analyseChart/analyseChartApiSlice";
import {
  setIsFiltersOpen,
  setPage,
  setPageLimit,
  updateFilters,
} from "../../features/analyseChart/analyseChartSlice";
import { changeKeyName, getFilterOptions } from "../../utils/common";
// import { useSearchInputMock } from "../../utils/mockdata/partitionGranularity";

function AnalyseChartFilter({ evalId }) {
  const dispatch = useDispatch();
  const [getEvalResults, { data: evalFilters }] = useGetEvalResultsMutation();
  // const MockData = [
  //   { value: "react", label: "React" },
  //   { value: "apple", label: "Apple" },
  //   { value: "apps", label: "Apps" },
  //   { value: "applaud", label: "Applaud" },
  //   { value: "ng", label: "Angular" },
  //   { value: "svelte", label: "Svelte" },
  //   { value: "vue", label: "Vue" },
  //   { value: "alpine", label: "Alpine" },
  //   { value: "ember", label: "Ember" },
  //   { value: "stimulus", label: "Stimulus" },
  //   { value: "preact", label: "Preact" },
  //   {
  //     value:
  //       "datasrc: int_claim_labresult | groupid: H704847 | client_id: null | client_ds_id: 7651 | segment_column_name: MAPPED_QUAL_CODE | segment_column_value: CH000652",
  //     label:
  //       "datasrc: int_claim_labresult | groupid: H704847 | client_id: null | client_ds_id: 7651 | segment_column_name: MAPPED_QUAL_CODE | segment_column_value: CH000652",
  //   },
  // ];

  const [analyseChartFilter, setAnalyseChartFilter] = useState({
    partitionGranularity: [],
    rule: [],
    modelName: [],
    columnName: [],
    ruleName: [],
    flaggedStatus: [],
    checkTags: [],
    includeSeverity: true,
    includeCore: false,
  });

  useEffect(() => {
    dispatch(setIsFiltersOpen(true));
    fetchEvalResults();
    return () => dispatch(setIsFiltersOpen(false));
  }, []);

  const fetchEvalResults = () => {
    getEvalResults({
      id: evalId,
      data: { metadata: true },
    });
  };

  const [isVisible, setIsVisible] = useState(false);
  const { isFiltersOpen } = useSelector((state) => state.analyseChart);

  const getFilterValues = (key) => {
    const filtersClone = { ...analyseChartFilter };

    /*deleting follwing filters because these are not dropdown fields */
    delete filtersClone["severity"];
    delete filtersClone["includeSeverity"];
    delete filtersClone["netNewCharts"];
    delete filtersClone["anomalyCharts"];
    delete filtersClone["includeCore"];
    let filterOpions = getFilterOptions(
      key,
      changeKeyName(filtersClone),
      evalFilters?.eval_results
    );

    // if key is flagged_status, remove FlagStatus. from prefix and replace "_" with ""
    if (key === "flagged_status") {
      filterOpions = filterOpions.map((option) => {
        return {
          ...option,
          label: option.label
            .replaceAll("FlagStatus.", "")
            .replaceAll("_", " "),
        };
      });
    }
    return filterOpions;
  };
  const setAnalyseChartFilterValues = (filter, value) => {
    setAnalyseChartFilter((prevState) => ({
      ...prevState,
      [filter]: value,
    }));
  };

  function onVisibilityChange(isVisible) {
    setIsVisible(isVisible);
  }

  const filterEvalCharts = () => {
    dispatch(setPage(1));
    dispatch(setPageLimit(10));
    dispatch(updateFilters(analyseChartFilter));
  };

  const resetFilters = () => {
    const newFilters = {
      rule: [],
      modelName: [],
      columnName: [],
      ruleName: [],
      checkTags: [],
      flaggedStatus: [],
      includeSeverity: true,
      includeCore: false,
    };
    dispatch(setPage(1));
    dispatch(setPageLimit(10));
    setAnalyseChartFilter(newFilters);
    dispatch(updateFilters(newFilters));
  };

  return (
    <>
      <div
        data-testid="analyse-chart-filters"
        className={`${
          isFiltersOpen ? "" : "shadow-[rgba(0,0,0,0.15)_1.95px_1.95px_2.6px]"
        } relative pt-4 pr-4 pl-4 overflow-y-scroll`}
      >
        <div className="flex justify-between items-center pb-4">
          <p className="text-base font-bold">
            <Filter className={"fill-[#09033f] mr-2 mb-1"} />
            {isFiltersOpen && <span>Filters</span>}
          </p>
          {isFiltersOpen ? (
            <Contract
              onClick={() => dispatch(setIsFiltersOpen(!isFiltersOpen))}
              className={"fill-[#09033f] cursor-pointer"}
            />
          ) : (
            <Expand
              onClick={() => dispatch(setIsFiltersOpen(!isFiltersOpen))}
              className={"fill-[#09033f] cursor-pointer"}
            />
          )}
        </div>
        {isFiltersOpen && (
          <>
            {/* <div className="pt-4">
              <SelectInputMulti
                label="Partition Granularity"
                placeholder="Select"
                isDisabled
                isSearchable
                enableOutsideScroll
                value={analyseChartFilter.partitionGranularity}
                onChange={(value) =>
                  setAnalyseChartFilterValues("partitionGranularity", value)
                }
                selectAll
                options={getFilterValues("partition_granularity")}
                data-testid="partition-granularity-filter"
              />
            </div> */}
            <div className="pt-4">
              <SelectInputMulti
                label="Rule Type"
                placeholder="Select"
                isSearchable
                hideChips
                fuseConfig={{ threshold: 0.3 }}
                enableOutsideScroll
                value={analyseChartFilter.rule}
                onChange={(value) => setAnalyseChartFilterValues("rule", value)}
                selectAll
                options={getFilterValues("rule")}
                data-testid="rule-type-filter"
              />
            </div>
            <div className="pt-4">
              <SelectInputMulti
                label="Model"
                placeholder="Select"
                isSearchable
                hideChips
                fuseConfig={{ threshold: 0.3, findAllMatches: true }}
                enableOutsideScroll
                value={analyseChartFilter.modelName}
                onChange={(value) =>
                  setAnalyseChartFilterValues("modelName", value)
                }
                selectAll
                options={getFilterValues("model_name")}
                data-testid="model-filter"
              />
            </div>
            <div className="pt-4">
              <SelectInputMulti
                label="Column"
                placeholder="Select"
                isSearchable
                hideChips
                fuseConfig={{ threshold: 0.3 }}
                enableOutsideScroll
                value={analyseChartFilter.columnName}
                onChange={(value) =>
                  setAnalyseChartFilterValues("columnName", value)
                }
                selectAll
                options={getFilterValues("column_name")}
                data-testid="column-filter"
              />
            </div>
            <div className="pt-4">
              <SelectInputMulti
                label="Rule Name"
                placeholder="Select"
                isSearchable
                hideChips
                fuseConfig={{ threshold: 0.3 }}
                enableOutsideScroll
                value={analyseChartFilter.ruleName}
                onChange={(value) =>
                  setAnalyseChartFilterValues("ruleName", value)
                }
                selectAll
                options={getFilterValues("rule_name")}
                data-testid="rule-name-filter"
              />
            </div>
            <div className="pt-4">
              <SelectInputMulti
                label="Flag Type"
                placeholder="Select"
                isSearchable
                hideChips
                fuseConfig={{ threshold: 0.3 }}
                enableOutsideScroll
                value={analyseChartFilter.flaggedStatus}
                onChange={(value) =>
                  setAnalyseChartFilterValues("flaggedStatus", value)
                }
                selectAll
                options={getFilterValues("flagged_status")}
                data-testid="flag-type-filter"
              />
            </div>
            <div className="pt-4">
              <SelectInputMulti
                label="Tags"
                placeholder="Select"
                isSearchable
                hideChips
                fuseConfig={{ threshold: 0.3 }}
                enableOutsideScroll
                value={analyseChartFilter.checkTags}
                onChange={(value) => {
                  setAnalyseChartFilterValues("checkTags", value);
                }}
                selectAll
                options={getFilterValues("check_tags")}
                data-testid="flag-type-filter"
              />
            </div>
            {/* <div className="pt-4">
              <SelectInputMulti
                label="Quality Dimension"
                placeholder="Select"
                isSearchable
                hideChips
                fuseConfig={{ threshold: 0.3 }}
                enableOutsideScroll
                value={analyseChartFilter.checkQualityDimension}
                onChange={(value) =>
                  setAnalyseChartFilterValues("checkQualityDimension", value)
                }
                selectAll
                options={getFilterValues("check_quality_dimension")}
                data-testid="check-quality-dimension-filter"
              />
            </div> */}
            <VisibilitySensor
              onChange={(visible) => onVisibilityChange(visible)}
            >
              {() => (
                <div className="pt-4">
                  <FormControl id={"analyse-chart-checkboxes"}>
                    <Checkbox
                      role="include-core-checkbox"
                      checked={analyseChartFilter.includeCore}
                      className="mb-5"
                      name={"includeCore"}
                      onChange={(e) =>
                        setAnalyseChartFilterValues(
                          "includeCore",
                          e.target.checked
                        )
                      }
                      data-testid={`include-core-checkbox`}
                    >
                      Show Only Core Rules
                    </Checkbox>
                  </FormControl>
                </div>
              )}
            </VisibilitySensor>
          </>
        )}
      </div>
      {isFiltersOpen && (
        <div
          className={`${
            !isVisible
              ? "fixed bottom-0 z-50 bg-[#fbf9f4] w-full max-w-[calc(24%-41px)] pt-0"
              : "relative"
          }`}
        >
          <div className="absolute w-full border-solid border-t border-[#E0E0E0] left-0"></div>
          <Button
            className="ml-4 mt-4 mb-4"
            onClick={() => filterEvalCharts()}
            data-testid="filter-apply-btn"
          >
            Apply
          </Button>
          <Button
            className="ml-4"
            variant="ghost"
            onClick={() => resetFilters()}
            data-testid="filter-apply-btn"
          >
            Reset
          </Button>
        </div>
      )}
    </>
  );
}

AnalyseChartFilter.propTypes = {
  evalId: PropTypes.string,
};

export default AnalyseChartFilter;
