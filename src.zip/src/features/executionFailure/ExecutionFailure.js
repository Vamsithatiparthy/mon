import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useMediaQuery } from "react-responsive";
import { Badge } from "@abyss/web/ui/Badge";
import { SelectInputMulti } from "@abyss/web/ui/SelectInputMulti";
import { TextInput } from "@abyss/web/ui/TextInput";
import { ToggleSwitch } from "@abyss/web/ui/ToggleSwitch";
import {
  Button,
  Checkbox,
  FormControl,
  Label,
  Pagination,
  RadioButton,
  Table,
  Tooltip,
} from "@uitk/react";
import {
  InfoFilled,
  InfoHollow,
  SortAscending,
  SortDescending,
  SortUnsorted,
} from "@uitk/react-icons";
import PropTypes from "prop-types";
import { v4 as uuidv4 } from "uuid";

import ActionDrawer from "../../components/ActionDrawer/ActionDrawer";
import Summary from "../../components/summary/Summary";
import {
  toggleSaveChanges,
  updateStepButtons,
} from "../../pages/evalReport/evalReportSlice";
import { countRecords, getFilterOptions } from "../../utils/common";
import { constant, saveConstants } from "../../utils/constants";

import {
  selectEvalFailures,
  selectTableDataEvalFailures,
  setEvalFailures,
  updateFilters,
  updateTableHeader,
} from "./evalFailuresSlice";

function ExecutionFailure({ evalFailures, saveChanges }) {
  const dispatch = useDispatch();

  const initialSortValues = {
    icon: <SortUnsorted />,
    sortDirection: 0,
  };
  // This contains all the eval failures records
  const evalFailuresData = useSelector(selectEvalFailures);
  // This contains data shown in the eval failures table.
  const evalFailuresTableData = useSelector(selectTableDataEvalFailures);
  // const { reasonTooltipVisbility } = useSelector((state) => state.evalFailures);
  const { actionBtnHeight } = useSelector((state) => state.evalFailures);
  const { saveChangesEnabled } = useSelector((state) => state.evalReport);
  const [filters, setFilters] = useState({
    category: [],
    model: [],
    column: [],
    reason: "",
    hideRecurring: false,
  });
  const [selectallchecked, setSelectAllChecked] = useState(false);
  const [openActionDrawer, setOpenActionDrawer] = useState(false);
  const [disableActionBtn, setDisableActionBtn] = useState(true);
  const [bulkFailureAction, setBulkFailureAction] = useState("none");
  const isTabletOrMobile = useMediaQuery({ query: "(max-width: 1224px)" });
  const [page, setPage] = useState(1);

  const [tableHeaders, setTableHeaders] = useState({
    category: initialSortValues,
    is_recurring: {
      icon: <SortDescending />,
      sortDirection: -1,
    },
    column: initialSortValues,
    model: initialSortValues,
  });

  useEffect(() => {
    applyFilters();
  }, [filters.hideRecurring]);

  useEffect(() => {
    if (evalFailures) {
      dispatch(setEvalFailures(evalFailures));
    }
  }, []);

  useEffect(() => {
    setPage(1);
  }, [evalFailuresTableData]);

  const onCheckboxChange = (e) => {
    let isAnySelected = false;
    const evalFailures = evalFailuresData.map((ele) => {
      if ((ele.checked && ele.id != e?.target?.name) || e.target.checked) {
        isAnySelected = true;
      }
      return ele.id === e?.target?.name
        ? { ...ele, checked: !ele.checked }
        : ele;
    });
    setBulkAction(evalFailures);
    if (
      getCheckedCount(evalFailures) == 1 &&
      getCheckedCount(evalFailuresData) == 0
    ) {
      setOpenActionDrawer(true);
    }

    dispatch(setEvalFailures(evalFailures));
    const countChecked = countRecords(evalFailures, "checked");
    updateSelectAllCheckboxState("indeterminate", isAnySelected ? true : false);
    if (countChecked["true"] == evalFailures.length) {
      updateSelectAllCheckboxState("indeterminate", false);
      updateSelectAllCheckboxState("checked", true);
    }
  };

  const updateSelectAllCheckboxState = (state, value) => {
    document.getElementById(`${constant.SELECT_ALL}`)[state] = value;
  };

  const setBulkAction = (evalFailures) => {
    const checkedEvalFailures = evalFailures.filter(
      (element) => element.checked
    );
    const getCount = countRecords(checkedEvalFailures, "failure_action");
    const failure_action =
      getCount[constant.IGNORED] == checkedEvalFailures.length
        ? constant.IGNORED
        : getCount[constant.MARKED_FOR_RERUN] == checkedEvalFailures.length
        ? constant.MARKED_FOR_RERUN
        : "none";
    setBulkFailureAction(failure_action);
  };

  const onRadioBtnChange = (e, bulkAction) => {
    if (!bulkAction) {
      const evalFailures = evalFailuresData.map((ele) =>
        ele.id === e?.target?.name
          ? {
              ...ele,
              failure_action: e?.target?.value,
              updated: true,
              error: false,
            }
          : ele
      );
      dispatch(setEvalFailures(evalFailures));
      setBulkAction(evalFailures);
      if (!saveChangesEnabled) {
        dispatch(toggleSaveChanges(true));
        dispatch(
          updateStepButtons({ enableNextStep: false, enablePrevStep: false })
        );
      }
    } else {
      setDisableActionBtn(false);
      setBulkFailureAction(e?.target?.value);
    }
  };

  const selectAllCheckbox = (e) => {
    const isAnySelected = document.getElementById(
      `${constant.SELECT_ALL}`
    ).indeterminate;
    const checkedStatus = isAnySelected ? false : e?.target?.checked;
    setSelectAllChecked(checkedStatus);
    const updatedArray = evalFailuresData.map((element) => {
      const updatedRecord = evalFailuresTableData.find(
        (ele) => ele.id === element.id
      );
      return updatedRecord ? { ...element, checked: checkedStatus } : element;
    });
    setBulkAction(updatedArray);
    if (checkedStatus) {
      setOpenActionDrawer(true);
    }
    dispatch(setEvalFailures(updatedArray));
  };

  const renderFailureActions = (
    id,
    igonreRadioChecked,
    rerunRadioChecked,
    bulkAction,
    error
  ) => {
    return (
      <>
        <FormControl
          id={id}
          data-testid={"failure-actions"}
          disabled={getCheckedCount(evalFailuresData) == 0 && bulkAction}
          className={`${"radio-formcontrol"}${error ? " error" : ""}`}
        >
          <RadioButton
            onChange={(e) => onRadioBtnChange(e, bulkAction)}
            checked={igonreRadioChecked}
            name={id}
            value={constant.IGNORED}
            className="eval-failure-ignored"
            data-testid={`eval-failure-ignored-${id}`}
          >
            Ignore
          </RadioButton>
          <RadioButton
            checked={rerunRadioChecked}
            onChange={(e) => onRadioBtnChange(e, bulkAction)}
            name={id}
            value={constant.MARKED_FOR_RERUN}
            className="eval-failure-mark-rerun"
            data-testid={`eval-failure-rerun-${id}`}
          >
            Mark for Rerun
          </RadioButton>
        </FormControl>
      </>
    );
  };

  const showFailureAction = ({ failure_action, id, error }) => {
    const igonreRadioChecked = failure_action === constant.IGNORED;
    const rerunRadioChecked = failure_action === constant.MARKED_FOR_RERUN;

    return (
      <>
        {renderFailureActions(
          id,
          igonreRadioChecked,
          rerunRadioChecked,
          false,
          error
        )}
      </>
    );
  };

  const showRowCheckbox = ({ id, checked }) => {
    const key = uuidv4();
    return (
      <>
        <FormControl id={key}>
          <Checkbox
            role="execution-failure-checkbox"
            checked={checked}
            className={checked ? "checked" : ""}
            name={id}
            onChange={(e) => onCheckboxChange(e)}
            data-testid={`execution-failure-checkbox-${id}`}
          />
        </FormControl>
      </>
    );
  };
  const getReasonTooltipContent = (reason, id) => {
    return (
      <span id={id}>
        <p id={id}>{reason}</p>
      </span>
    );
  };
  const renderReasonColumn = ({ id, reason }) => {
    return (
      <>
        <Tooltip
          content={getReasonTooltipContent(reason, id)}
          className="reason-tooltip"
          placement="bottom"
        >
          <p id={id}>{reason}</p>
        </Tooltip>
      </>
    );
  };

  const showFrequency = ({ is_recurring }) => {
    const frequency = is_recurring ? "recurring" : "non-recurring";
    return (
      <>
        <Badge
          rounded
          variant="warning"
          outline={false}
          ariaText="information"
          className={frequency}
        >
          {frequency}
        </Badge>
      </>
    );
  };

  const showColumn = ({ column }) => {
    return <>{column === "null" ? "" : column}</>;
  };

  const tableSort = (sortColumnKey, sortDirection) => {
    const newTableHeader = { ...tableHeaders };
    for (const key in newTableHeader) {
      newTableHeader[key] = initialSortValues;
    }
    newTableHeader[sortColumnKey] = {
      icon: sortDirection == 1 ? <SortAscending /> : <SortDescending />,
      sortDirection: sortDirection,
    };
    setTableHeaders(newTableHeader);
    dispatch(updateTableHeader({ sortColumnKey, sortDirection }));
  };

  const renderLabel = (label, key) => {
    return (
      <>
        <span
          className={`table-header ${
            tableHeaders[key].sortDirection != 0 ? "table-header-sorted" : ""
          }`}
          onClick={() =>
            tableSort(
              key,
              tableHeaders[key].sortDirection == 0
                ? 1
                : -tableHeaders[key].sortDirection
            )
          }
        >
          {label}
          {tableHeaders[key].icon}
        </span>
      </>
    );
  };

  const onPageChange = (page) => {
    setPage(page);
  };

  const config = {
    columns: [
      {
        label: "",
        onRenderCell: showRowCheckbox,
      },
      {
        label: renderLabel("Category", "category"),
        key: "category",
      },
      {
        label: renderLabel("Frequency", "is_recurring"),
        onRenderCell: showFrequency,
      },
      {
        label: renderLabel("Model", "model"),
        key: "model",
      },
      {
        label: renderLabel("Column", "column"),
        key: "column",
        onRenderCell: showColumn,
      },
      {
        label: "Reason",
        onRenderCell: renderReasonColumn,
      },
      {
        label: "Failure Actions",
        onRenderCell: showFailureAction,
      },
    ],
    sort: false,
    sticky: {
      isHeaderSticky: true,
    },
  };

  const paginationConfig = {
    pageSize: 10,
    totalItemsCount: evalFailuresTableData?.length,
    enableGotoPage: true,
  };

  const entriesPerPageConfig = {
    pageSizeOptions: [
      {
        label: "10",
        value: 10,
      },
      {
        label: "50",
        value: 50,
      },
      {
        label: "100",
        value: 100,
      },
    ],
    initialValue: 10,
  };

  const getSummaryInput = () => {
    const total = {
      key: "Total",
      value: evalFailures?.length,
    };

    const initialRecords = [
      {
        key: constant.IGNORED,
        value: 0,
      },
      {
        key: constant.MARKED_FOR_RERUN,
        value: 0,
      },
    ];
    const failureActionDetails = countRecords(
      evalFailuresData,
      "failure_action",
      initialRecords
    );
    if (failureActionDetails["null"] != undefined) {
      failureActionDetails["unfilled"] = failureActionDetails["null"];
      delete failureActionDetails["null"];
    }
    const summaryInput = [
      {
        header: "Record Details",
        icon: "",
        details: countRecords(evalFailuresData, "category", [], true),
        totalRecords: total,
      },
      {
        header: "Actions",
        icon: (
          <Tooltip
            content={constant.ACTION_SUMMARY}
            className="summary-tooltip"
          >
            <InfoHollow />
          </Tooltip>
        ),
        details: failureActionDetails,
      },
    ];
    return summaryInput;
  };

  const applyFilters = () => {
    dispatch(updateFilters(filters));
  };

  const onReset = () => {
    const resetFiltersValue = {
      category: [],
      reason: "",
      column: [],
      model: [],
      hideRecurring: false,
    };
    setFilters(resetFiltersValue);
    dispatch(updateFilters(resetFiltersValue));
  };

  const setIsOpen = (open) => {
    setOpenActionDrawer(open);
    setDisableActionBtn(true);
  };

  const onBulkAction = () => {
    const evalFailures = evalFailuresData.map((obj) => ({
      ...obj,
      failure_action: obj.checked ? bulkFailureAction : obj.failure_action,
      updated: obj.checked ? true : obj.updated,
    }));
    dispatch(setEvalFailures(evalFailures));
    setOpenActionDrawer(false);
    dispatch(toggleSaveChanges(true));
    dispatch(
      updateStepButtons({ enableNextStep: false, enablePrevStep: false })
    );
  };

  const getCheckedCount = (evalFailuresData) => {
    let count = 0;
    evalFailuresData.forEach((element) => {
      count = element.checked ? count + 1 : count;
    });
    return count;
  };

  const getActionDrawerContent = () => {
    const igonreRadioChecked = bulkFailureAction === constant.IGNORED;
    const rerunRadioChecked = bulkFailureAction === constant.MARKED_FOR_RERUN;
    return (
      <div className="action-container" data-testid="action-container">
        <div className="action-content">
          <p>Failure Actions</p>
          {renderFailureActions(
            100,
            igonreRadioChecked,
            rerunRadioChecked,
            true,
            false
          )}
        </div>
      </div>
    );
  };

  const setFilterValues = (filter, value) => {
    setFilters((prevState) => ({
      ...prevState,
      [filter]: value,
    }));
  };

  const getFilterValues = (key) => {
    const filtersClone = { ...filters };
    /*deleting hideRecurring and reason filter because these are not dropdown fields */
    delete filtersClone["reason"];
    return getFilterOptions(key, filtersClone, evalFailuresData);
  };

  const getFilter = () => {
    return (
      <div className="filter-container">
        <div className="filter-header">Filter</div>
        <div className="filter-content row">
          <div className="filter-content-left col-s-12 col-m-12  col-l-12 row">
            <div className="form-multi-select col-s-2 col-m-2 col-l-2">
              {" "}
              <SelectInputMulti
                label="Category"
                placeholder="Select"
                isSearchable
                enableOutsideScroll
                value={filters.category}
                onChange={(value) => setFilterValues("category", value)}
                selectAll
                options={getFilterValues("category")}
                data-testid="category-filter"
              />
            </div>
            <div className="form-multi-select col-s-2 col-m-2 col-l-2">
              <SelectInputMulti
                label="Model"
                placeholder="Select"
                isSearchable
                value={filters.model}
                onChange={(value) => setFilterValues("model", value)}
                enableOutsideScroll
                selectAll
                options={getFilterValues("model")}
                data-testid="model-filter"
              />
            </div>
            <div className="form-multi-select col-s-2 col-m-2 col-l-2">
              <SelectInputMulti
                label="Column"
                placeholder="Select"
                isSearchable
                value={filters.column}
                onChange={(value) => setFilterValues("column", value)}
                enableOutsideScroll
                selectAll
                options={getFilterValues("column")}
                data-testid="column-filter"
              />
            </div>
            <div className="filter-reason col-s-4 col-m-2 col-l-2">
              {" "}
              <TextInput
                placeholder="Enter keywords"
                label="Reason"
                value={filters.reason}
                onChange={(e) => setFilterValues("reason", e.target.value)}
                onClear={() => setFilterValues("reason", "")}
                data-testid="reason-filter"
              />
            </div>
            <div className="filter-buttons col-s-12 col-m-3 col-l-2">
              <Button
                className="apply-button"
                onClick={() => applyFilters()}
                data-testid="filter-apply-btn"
              >
                Apply
              </Button>
              <Button
                className="apply-button"
                onClick={onReset}
                variant="ghost"
              >
                Reset
              </Button>
            </div>
            <div className="toggle-container col-l-2">
              <Label>Hide Recurring Failures</Label>

              <ToggleSwitch
                isChecked={filters.hideRecurring}
                onChange={(e) =>
                  setFilters((prevState) => ({
                    ...prevState,
                    hideRecurring: e.target.checked,
                  }))
                }
                data-testid="recurring-filter"
              />
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="execution-failure">
      <div className="execution-failure-summary row">
        <div className="col">
          <h1 className="summary-header">Summary</h1>
          <p className="summary-sub-header">
            DVP execution failure categories
            <Button
              disabled={!saveChangesEnabled}
              onPress={() => saveChanges()}
              data-testid="save-changes-btn"
            >
              {saveConstants.SAVE_CHANGES}
            </Button>
          </p>
          <Summary summaryProps={getSummaryInput} />
        </div>
      </div>
      <div className="ef-details">
        <h1 className="detail-header">DVP Execution Failure Details</h1>
        {getFilter()}
      </div>

      <div className="execution-failure-table">
        <Pagination
          id="pagination-entries"
          config={paginationConfig}
          entriesPerPageConfig={entriesPerPageConfig}
          onPageChange={onPageChange}
          page={page}
          className={`${
            evalFailuresTableData.length === 0 ? "no-pagination" : "pagination"
          }`}
        >
          {({ pageSize }) => (
            <>
              <div className="table-header">
                <div className="table-header-left">
                  <div className="select-all-checkbox">
                    <FormControl id={`${constant.SELECT_ALL}`}>
                      <Checkbox
                        checked={selectallchecked}
                        role="execution-failure-selectall-checkbox"
                        onChange={selectAllCheckbox}
                      >
                        Select All
                      </Checkbox>
                    </FormControl>
                  </div>
                  <div className="table-header-message">
                    {isTabletOrMobile && (
                      <Tooltip
                        content={constant.TABLE_HEADER_MESSAGE}
                        placement="bottom"
                        className="client-details-tooltip"
                      >
                        <InfoFilled className="table-info-icon" />
                      </Tooltip>
                    )}
                    {!isTabletOrMobile && (
                      <>
                        <InfoFilled className="table-info-icon" />
                        <span>{constant.TABLE_HEADER_MESSAGE}</span>
                      </>
                    )}
                  </div>
                </div>
                <ActionDrawer
                  open={openActionDrawer}
                  setIsOpen={setIsOpen}
                  content={getActionDrawerContent}
                  checkedCount={getCheckedCount(evalFailuresData)}
                  onApply={onBulkAction}
                  disabled={disableActionBtn}
                  mixedValue={
                    bulkFailureAction === "none" &&
                    getCheckedCount(evalFailuresData) != 0
                  }
                  actionBtnHeight={actionBtnHeight}
                />
              </div>
              <Table
                id="test1"
                role="execution-failure-table"
                data={evalFailuresTableData}
                config={config}
                className="execution-failure-table"
                page={page}
                pageSize={pageSize}
              />
              {evalFailuresTableData.length === 0 && (
                <div className="no-records-message">
                  <p>No records to show.</p>
                </div>
              )}
            </>
          )}
        </Pagination>
      </div>
    </div>
  );
}

ExecutionFailure.propTypes = {
  evalFailures: PropTypes.array,
  saveChanges: PropTypes.func,
};

export default ExecutionFailure;
