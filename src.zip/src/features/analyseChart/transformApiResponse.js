/* Get the layout for plotly to construct chart */
const getChartLayout = (column = 1, text = "") => {
  return {
    autosize: true,
    legend: {
      x: 1,
      y: 0.5,
    },
    showlegend: true,
    grid: {
      rows: 1,
      columns: column,
      pattern: "independent",
    },
    title: {
      text: text,
    },
    hovermode: "x",
    hoverlabel: {
      align: "left",
    },
    // changing the xaxis type to category to show the xaxis values as string
    xaxis: {
      type: "category",
    },
    xaxis2: {
      type: "category",
    },
    xaxis3: {
      type: "category",
    },
  };
};

/* Get the traces for plotly to construct chart - traces are x axis points, y axis points
and hover text like information that we want in our chart */
const getChartTraces = (
  curr,
  name,
  type,
  x,
  y,
  xaxis,
  yaxis,
  text,
  visible = ""
) => {
  let display = true;
  // if confidence score is less than or equal to 2, then hide the trace for lower bound and upper bound
  if (curr.confidence_score <= 2) {
    display = name === "Lower Bound" || name === "Upper Bound" ? false : true;
  }
  // if confidence score is zero, then hide the trace for previous build value, lower bound and upper bound
  if (curr.confidence_score === 0) {
    display =
      name === "Previous Build Value" ||
      name === "Lower Bound" ||
      name === "Upper Bound"
        ? false
        : true;
    visible =
      name === "Previous Build Value" ||
      name === "Lower Bound" ||
      name === "Upper Bound"
        ? false
        : true;
  }

  return {
    name,
    type,
    mode: "lines+markers",
    x,
    y,
    xaxis,
    yaxis,
    hoverinfo: "text",
    text,
    visible,
    showlegend: display,
  };
};

/* get what text to show when hover on timeseries graph points */
const getTimeSeriesText = (
  timeseries_column_value,
  timeseries_current_value,
  previous_build_value
) => {
  function getPercentageChange(current, previous) {
    if (Math.ceil(parseFloat(previous)) === 0) {
      return 100;
    } else {
      return parseFloat(
        (
          ((parseFloat(current) - parseFloat(previous)) * 100) /
          parseFloat(previous)
        ).toFixed(4)
      );
    }
  }

  function getDeltaWithPrevious(current, previous) {
    return parseFloat(current) - parseFloat(previous);
  }
  return `Time Series: <b>${timeseries_column_value}</b><br>Current Build Value:<b>${timeseries_current_value}</b><br>Previous Build Value: <b>${previous_build_value}</b><br>Delta of builds: <b>${getDeltaWithPrevious(
    timeseries_current_value,
    previous_build_value
  )}</b><br>% Change: <b>${getPercentageChange(
    timeseries_current_value,
    previous_build_value
  )}</b>`;
};

/* Below function will do the following:
  1) Process the response from API for rateanalysis records
  2) Rateanalysis construct three charts for numerator, denominator and rate
  3) Construct data required to uitk table for numerator, denominator and rate
  4) Single api record is sufficient to generate rateanalysis chart unlike timeseries
*/
const processRateOrClass = (acc, curr, key) => {
  acc[key] = { ...curr };
  const numerator = getChartTraces(
    curr,
    "Numerator",
    "scatter",
    curr["numerator"].map((element) => element.ref_key),
    curr["numerator"].map((element) => element.value),
    "x1",
    "y1",
    curr["numerator"].map((element) => element.value)
  );
  const denominator = getChartTraces(
    curr,
    "Denominator",
    "scatter",
    curr["denominator"].map((element) => element.ref_key),
    curr["denominator"].map((element) => element.value),
    "x2",
    "y2",
    curr["denominator"].map((element) => element.value)
  );
  const rate = getChartTraces(
    curr,
    "Rate (%)",
    "scatter",
    curr["historic_trend"].map((element) => element.ref_key),
    curr["historic_trend"].map((element) => element.value * 100),
    "x3",
    "y3",
    curr["historic_trend"].map((element) => element.value * 100)
  );
  acc[key]["chart_value"] = [numerator, denominator, rate];
  acc[key]["chart_layout"] = getChartLayout(
    3,
    "Numerator | Denominator | Rate (%)"
  );
  const table_content_cols = [
    {
      label: "build",
      key: "build",
      onRenderCell: ({ failure_class, build }) => (
        <span className={`${failure_class ? "failure_row" : ""}`}>{build}</span>
      ),
    },
    { label: "numerator", key: "numerator" },
    { label: "denominator", key: "denominator" },
    { label: "rate (%)", key: "rate" },
  ];

  acc[key]["table_content_cols"] = table_content_cols;
  let table_content = [];
  for (let i = 0; i < curr["historic_trend"].length; i++) {
    table_content.push({
      build: curr.historic_trend[i].ref_key,
      numerator: curr.numerator[i].value,
      denominator: curr.denominator[i].value,
      rate: curr.historic_trend[i].value * 100,
      failure_class: i === curr["historic_trend"].length - 1 ? true : false,
    });
  }
  acc[key]["table_content"] = table_content;
};
const processthreshold = (acc, curr, key) => {
  acc[key] = { ...curr };
  const table_content_cols = [
    {
      label: "build",
      key: "build",
      onRenderCell: ({ failure_class, build }) => (
        <span className={`${failure_class ? "failure_row" : ""}`}>{build}</span>
      ),
    },
    { label: "numerator", key: "numerator" },
    { label: "denominator", key: "denominator" },
    { label: "rate (%)", key: "rate" },
  ];

  acc[key]["table_content_cols"] = table_content_cols;
  let table_content = [];
  for (let i = 0; i < curr["historic_trend"].length; i++) {
    table_content.push({
      build: curr.historic_trend[i].ref_key,
      numerator: curr.numerator[i].value,
      denominator: curr.denominator[i].value,
      rate: curr.historic_trend[i].value * 100,
      failure_class: i === curr["historic_trend"].length - 1 ? true : false,
    });
  }
  acc[key]["table_content"] = table_content;
};

/* Below function will do the following:
  1) This function will only be called when it first encounters timeseries record for a unique rule_group_num
  2) Timeseries requires 61 data points to constrct chart, so from this function it will only get one data point
  3) Construct data required to uitk table for timeseries chart table
  4) Single api record is not sufficient to generate entire timeseries chart, 61 records will be required to generate a single timeseries chart
  5) Below function will initialize chart_value with lower_bound, upper_bound, current_build_value and previous_build_value and later will
     push the remaining 60 data points to each in updateTimeSeries function
*/
const processTimeSeries = (acc, curr, key) => {
  const clonedCurr = Object.assign({}, curr);
  clonedCurr["timeseries_upper_bound"] =
    clonedCurr["timeseries_upper_bound"] || 0;
  clonedCurr["timeseries_lower_bound"] =
    clonedCurr["timeseries_lower_bound"] || 0;
  acc[key] = { ...clonedCurr };
  const lower_bound = getChartTraces(
    clonedCurr,
    "Lower Bound",
    "scatter",
    [clonedCurr.timeseries_column_value],
    [clonedCurr.timeseries_lower_bound],
    "",
    "",
    [clonedCurr.timeseries_lower_bound],
    "legendonly"
  );
  const upper_bound = getChartTraces(
    clonedCurr,
    "Upper Bound",
    "scatter",
    [clonedCurr.timeseries_column_value],
    [clonedCurr.timeseries_upper_bound],
    "",
    "",
    [clonedCurr.timeseries_upper_bound],
    "legendonly"
  );

  const current_build_value = getChartTraces(
    clonedCurr,
    "Current Build Value",
    "scatter",
    [clonedCurr.timeseries_column_value],
    [clonedCurr.timeseries_current_value],
    "",
    "",
    [
      getTimeSeriesText(
        clonedCurr.timeseries_column_value,
        clonedCurr.timeseries_current_value,
        clonedCurr.denominator[0].value
      ),
    ],
    "true"
  );
  const previous_build_value = getChartTraces(
    clonedCurr,
    "Previous Build Value",
    "scatter",
    [clonedCurr.timeseries_column_value],
    [clonedCurr.denominator[0].value],
    "",
    "",
    [clonedCurr.denominator[0].value],
    "true"
  );

  acc[key]["chart_value"] = [
    lower_bound,
    upper_bound,
    current_build_value,
    previous_build_value,
  ];
  const confidence_score = acc[key].confidence_score;
  // generate table for timeseries
  const baseColumns = [
    {
      label: "timeseries_column_value",
      key: "timeseries_column_value",
      onRenderCell: ({ failure_class, timeseries_column_value }) => (
        <span className={`${failure_class ? "failure_row" : ""}`}>
          {timeseries_column_value}
        </span>
      ),
    },
    { label: "current_build_value", key: "current_build_value" },
  ];

  const prevBuildValueColumn = [
    { label: "previous_build_value", key: "previous_build_value" },
  ];

  const additionalColumns = [
    {
      label: "lower_bound",
      key: "lower_bound",
    },
    { label: "upper_bound", key: "upper_bound" },
  ];
  const table_content_cols =
    confidence_score > 2
      ? [...baseColumns, ...prevBuildValueColumn, ...additionalColumns]
      : confidence_score >= 1
      ? [...baseColumns, ...prevBuildValueColumn]
      : [...baseColumns];
  acc[key]["table_content_cols"] = table_content_cols;
  // generate table data for timeseries
  const baseTableContent = [
    {
      timeseries_column_value: clonedCurr.timeseries_column_value,
      current_build_value: clonedCurr.timeseries_current_value,
      previous_build_value: clonedCurr.denominator[0].value,
      failure_class: !clonedCurr.is_success,
    },
  ];
  const additionalTableContent = [
    {
      lower_bound: clonedCurr.timeseries_lower_bound,
      upper_bound: clonedCurr.timeseries_upper_bound,
    },
  ];
  const table_content =
    confidence_score > 2
      ? [{ ...baseTableContent[0], ...additionalTableContent[0] }]
      : baseTableContent;
  acc[key]["table_content"] = table_content;
  acc[key]["chart_layout"] = getChartLayout();
};

/* Below function will do the following:
  1) This function will be called when a rule_group_num record is encountered again in transformEvalChartsRespnse function
  2) It will add the points of this encountred record to the existing record present
  3) It will push the data for chart table
*/
const updateTimeSeries = (record, acc, curr, key) => {
  const clonedCurr = Object.assign({}, curr);
  clonedCurr["timeseries_upper_bound"] =
    clonedCurr["timeseries_upper_bound"] || 0;
  clonedCurr["timeseries_lower_bound"] =
    clonedCurr["timeseries_lower_bound"] || 0;
  // below array contains properties that needs to be updated for each chart_value indexe value
  const propertiesToUpdate = ["x", "y", "text"];
  // iterate every record of chart_value and update the properties
  const chart_value = record["chart_value"].map((item, index) => {
    const updatedItem = { ...item };
    propertiesToUpdate.forEach((prop) => {
      let valueToUpdate = clonedCurr[`timeseries_column_value`];
      if (prop === "y" || prop === "text") {
        // index = 0 means lower_bound, index = 1 means upper_bound,
        // index = 2 means current_build_value, index = 3 means previous_build_value
        // based on index and prop, update the value
        if (index === 1) {
          valueToUpdate = clonedCurr["timeseries_upper_bound"];
        } else if (index === 2) {
          if (prop === "text") {
            valueToUpdate = getTimeSeriesText(
              clonedCurr.timeseries_column_value,
              clonedCurr.timeseries_current_value,
              clonedCurr.denominator[0].value
            );
          } else {
            valueToUpdate = clonedCurr["timeseries_current_value"];
          }
        } else if (index === 3) {
          valueToUpdate = clonedCurr?.denominator[0]?.value;
        } else {
          valueToUpdate = clonedCurr["timeseries_lower_bound"];
        }
      }
      updatedItem[prop].push(valueToUpdate);
    });
    return updatedItem;
  });
  // push the data for chart table
  const table_content_row = {
    timeseries_column_value: clonedCurr.timeseries_column_value,
    lower_bound: clonedCurr.timeseries_lower_bound,
    current_build_value: clonedCurr.timeseries_current_value,
    upper_bound: clonedCurr.timeseries_upper_bound,
    previous_build_value: clonedCurr.denominator[0].value,
    failure_class: !clonedCurr.is_success,
  };
  acc[key] = {
    ...record,
    is_success: acc[key]
      ? acc[key].is_success && clonedCurr.is_success
      : clonedCurr.is_success,
    chart_value: chart_value,
    severity: Math.max(record.severity, clonedCurr.severity),
    confidence_score: Math.max(
      record.confidence_score,
      clonedCurr.confidence_score
    ),
    anomaly_type: clonedCurr.anomaly_type
      ? clonedCurr.anomaly_type
      : record.anomaly_type,
    is_core: clonedCurr.is_core ? clonedCurr.is_core : record.is_core,
    is_net_new: clonedCurr.is_net_new
      ? clonedCurr.is_net_new
      : record.is_net_new,
    flagged_status: clonedCurr.is_success
      ? record.flagged_status
      : clonedCurr.flagged_status,
    table_content: [...acc[key]["table_content"], table_content_row],
  };
};

/* Below function will do the following:
  1) Process the response from API for numdist records
  2) Numdistanalysis construct single chart for current build value and previous build value
  3) Construct data required to uitk table for numdist
  4) Single api record is sufficient to generate numdist chart unlike timeseries
*/
const processNumDistAnalysis = (acc, curr, key) => {
  const xHistoricPercentile = curr.historic_percentiles[0];
  const yHistoricPercentile =
    curr.historic_percentiles[1] === undefined
      ? { value: new Array(7).fill(0) }
      : curr.historic_percentiles[1];
  acc[key] = { ...curr };
  // generate chart_value data which will be passed to plotly
  const current_build_value = {
    name: "Current Build Value",
    type: "scatter",
    mode: "lines+markers",
    x: ["0.0", "0.1", "0.25", "0.5", "0.75", "0.9", "1.0"],
    y: xHistoricPercentile.value,
    hoverinfo: "text",
    text: xHistoricPercentile.value,
  };
  const previous_build_value = {
    name: "Previous Build Value",
    type: "scatter",
    mode: "lines+markers",
    x: ["0.0", "0.1", "0.25", "0.5", "0.75", "0.9", "1.0"],
    y: yHistoricPercentile.value,
    hoverinfo: "text",
    text: yHistoricPercentile.value,
  };

  acc[key]["chart_value"] = new Array(
    current_build_value,
    previous_build_value
  );

  // generate chart table data
  const table_content_cols = [
    {
      label: "ref_key",
      key: "ref_key",
      onRenderCell: ({ failure_class, ref_key }) => (
        <span className={`${failure_class ? "failure_row" : ""}`}>
          {ref_key}
        </span>
      ),
    },
    { label: "pctl 0.0", key: "pctl_0.0" },
    { label: "pctl 0.1", key: "pctl_0.1" },
    { label: "pctl 0.25", key: "pctl_0.25" },
    { label: "pctl 0.5", key: "pctl_0.5" },
    { label: "pctl 0.75", key: "pctl_0.75" },
    { label: "pctl 0.9", key: "pctl_0.9" },
    { label: "pctl 1.0", key: "pctl_1.0" },
  ];

  acc[key]["table_content_cols"] = table_content_cols;
  const table_content = [
    xHistoricPercentile.value.reduce(
      (acc, curr, index) => {
        const key = table_content_cols[index + 1].key;
        acc[key] = curr;
        return acc;
      },
      {
        ref_key: xHistoricPercentile.ref_key,
        failure_class: true,
      }
    ),
    yHistoricPercentile.value.reduce(
      (acc, curr, index) => {
        const key = table_content_cols[index + 1].key;
        acc[key] = curr;
        return acc;
      },
      { ref_key: "Previous", failure_class: false }
    ),
  ];
  acc[key]["table_content"] = table_content;
  acc[key]["chart_layout"] = getChartLayout();
};

/* Below function will do the following:
  1) This function will be called when a rule_group_num record is encountered again in transformEvalChartsRespnse function
  2) It will add the points of this encountred record to the existing record present
  3) It will push the data for chart table
*/

function transformEvalChartsRespnse(evalCharts) {
  // sort the evalCharts based on timeseries_column_value
  // evalCharts?.slice()?.sort((a, b) => {
  //   const valA = a?.timeseries_column_value || 0;
  //   const valB = b?.timeseries_column_value || 0;
  //   return valA - valB;
  // });

  const transformedEvalCharts = evalCharts?.reduce((acc, curr) => {
    const key = `${curr.result_group_num}`;
    if (!acc[key]) {
      acc[key] = curr;
      if (
        curr["rule"] === "rateanalysis" ||
        curr["rule"] === "classdistanalysis"
      ) {
        processRateOrClass(acc, curr, key);
      } else if (curr["rule"] === "thresholdanalysis") {
        processthreshold(acc, curr, key);
      } else if (
        curr["rule"] === "timeseriesanalysis" ||
        curr["rule"] === "mad_qreg_timeseriesanalysis"
      ) {
        processTimeSeries(acc, curr, key);
      } else if (curr["rule"] === "numdistanalysis") {
        processNumDistAnalysis(acc, curr, key);
      }
    } else {
      const record = acc[key];
      if (
        curr["rule"] === "timeseriesanalysis" ||
        curr["rule"] === "mad_qreg_timeseriesanalysis"
      ) {
        updateTimeSeries(record, acc, curr, key);
      }
    }
    return acc;
  }, {});
  return transformedEvalCharts ? Object?.values(transformedEvalCharts) : [];
}

export { transformEvalChartsRespnse };
