import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Checkbox, FormControl, Tooltip } from "@uitk/react";
import { InfoHollow } from "@uitk/react-icons";
import { WarningFilled } from "@uitk/react-icons";
import PropTypes from "prop-types";

import { ReactComponent as InfoOutlineIcon } from "../../assets/InfoOutlineIcon.svg";
import { countRecords } from "../../utils/common";
import { constant } from "../../utils/constants";
import { selectEvalFailures } from "../executionFailure/evalFailuresSlice";

function QcSignOff({ setState, updateDisable, evalRunClicked }) {
  // This contains all the eval failures records
  const evalFailuresData = useSelector(selectEvalFailures);
  const [checked, setChecked] = useState(false);

  const getSummaryInput = () => {
    const initialRecords = [
      {
        key: constant.IGNORED,
        value: 0,
      },
      {
        key: constant.MARKED_FOR_RERUN,
        value: 0,
      },
    ];
    const failureActionDetails = countRecords(
      evalFailuresData,
      "failure_action",
      initialRecords
    );
    if (failureActionDetails["null"] != undefined) {
      failureActionDetails["unfilled"] = failureActionDetails["null"];
      delete failureActionDetails["null"];
    }
    // Check if failureActionDetails.marked_for_rerun is greater than 0
    if ((failureActionDetails["marked for rerun"] == 0) | checked) {
      updateDisable(false);
    } else {
      updateDisable(true);
    }

    const summaryInput = [
      {
        header: "Record Details",
        icon: (
          <Tooltip
            content={constant.ACTION_SUMMARY}
            className="summary-tooltip"
          >
            <InfoHollow />
          </Tooltip>
        ),
        details: failureActionDetails,
      },
    ];
    return summaryInput;
  };
  // This function shows Total record details if any
  const showTotalRecords = (element, details) => {
    return (
      <>
        {element?.totalRecords?.key && (
          <div
            className={`summaryTotal ${
              element?.totalRecords?.key && Object.keys(details).length > 0
                ? "summaryTotalVerticalLine"
                : ""
            }`}
          >
            <p>{element?.totalRecords?.key}</p>
            <p>{element?.totalRecords?.value}</p>
          </div>
        )}
      </>
    );
  };

  // This function shows all record details block
  const showDetails = (element, details) => {
    return (
      <div className="summaryDetails">
        {showTotalRecords(element, details)}
        {Object.keys(details).map((ele, index) => {
          const key = ele;
          const value = details[ele];
          return (
            <React.Fragment key={index}>
              <div className="summaryBlock">
                <p>{key}</p>
                {value != 0 && <p className="summaryCount">{value}</p>}
                {value == 0 && <p className="summaryCount">-</p>}
              </div>
            </React.Fragment>
          );
        })}
      </div>
    );
  };

  const summaryData = getSummaryInput();

  return (
    <div className="execution-failure">
      <div className="execution-failure-summary row qc-signoff">
        <div className="col">
          {evalRunClicked.report_status != null && (
            <div className="qc-signoff-banner justify-center pl-4">
              <InfoOutlineIcon />
              <p>
                QC {evalRunClicked.report_status} on{" "}
                {evalRunClicked.reviewed_on}
              </p>
            </div>
          )}
          <h1 className="summary-header">Summary</h1>
          <p className="summary-sub-header">DVP execution failure categories</p>
          <div className="summary row">
            {summaryData.map((element, index) => {
              const details = element.details;
              return (
                <div key={index} className={`summarySection w-[20%]`}>
                  <p className="summarySectionHeader">
                    {element.header}
                    {element.icon}
                  </p>
                  {showDetails(element, details)}
                </div>
              );
            })}
            <div className="w-[80%] flex flex-col items-center justify-center">
              <div className="bg-[#FBE299] p-4 rounded-[6px] flex items-center">
                <WarningFilled className="w-[24px] h-[24px] fill-[black]" />
                QC cannot be approved if a DVP failure is marked for rerun.
              </div>
              <div className="flex w-[60%] justify-between mt-2 items-center">
                <a
                  onClick={() => setState({ currentStep: 1 })}
                  className="text-[#002677] cursor-pointer"
                >
                  Review DVP Execution Failure
                </a>
                or
                <div>
                  <FormControl id="checkbox-basic">
                    <Checkbox
                      checked={checked}
                      onChange={() => setChecked(!checked)}
                    >
                      Override Rerun action and allow QC approval
                    </Checkbox>
                  </FormControl>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

QcSignOff.propTypes = {
  evalFailures: PropTypes.array,
  setState: PropTypes.func,
  updateDisable: PropTypes.func,
  evalRunClicked: PropTypes.object,
};

export default QcSignOff;
