import React from "react";
import { act, fireEvent, screen, waitFor } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";
import analyseChartEvalResult from "../../utils/mockdata/analyseChartEvalResult";

import AnalyseChartFilter from "./AnalyseChartFilter";

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <AnalyseChartFilter evalFilters={analyseChartEvalResult} />
      </Toolkit>
    );
  });
});

afterEach(() => {
  component.unmount();
});

describe("Renders Analyse Chart Filter Component correctly", () => {
  test("Renders Analyse Chart Filter Component correctly", async () => {
    expect(screen.getByTestId(/analyse-chart-filters/i)).toBeInTheDocument();
  });

  test("Filters renders correctly", async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/Filter/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Rule Type/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Model/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Column/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Rule Name/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Flag Type/i)[0]).toBeInTheDocument();
      expect(
        screen.getAllByText(/Include Severity:Nan/i)[0]
      ).toBeInTheDocument();
      expect(
        screen.getAllByText(/Show only Net New charts/i)[0]
      ).toBeInTheDocument();
      expect(
        screen.getAllByText(/Show only Anomaly charts/i)[0]
      ).toBeInTheDocument();
    });
  });

  test("Nested Filters works correctly", async () => {
    const ruleTypeFilter = await screen.findByTestId(
      "rule-type-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(ruleTypeFilter);

    const selectFirstOption = await screen.findAllByTestId(
      "rule-type-filter-abyss-select-input-multi-option"
    );
    fireEvent.click(selectFirstOption[1]);
    const modelFilter = await screen.findByTestId(
      "model-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(modelFilter);
    fireEvent.click(modelFilter);
    const modelOptions = await screen.findAllByTestId(
      "model-filter-abyss-select-input-multi-option"
    );
    expect(modelOptions.length).toBe(3);
    fireEvent.click(modelOptions[1]);

    const columnFilter = await screen.findByTestId(
      "column-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(columnFilter);
    fireEvent.click(columnFilter);
    const columnOptions = await screen.findAllByTestId(
      "column-filter-abyss-select-input-multi-option"
    );
    expect(columnOptions.length).toBe(3);
    fireEvent.click(columnOptions[1]);

    const ruleNameFilter = await screen.findByTestId(
      "rule-name-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(ruleNameFilter);
    fireEvent.click(ruleNameFilter);
    const ruleNameFilterOptions = await screen.findAllByTestId(
      "rule-name-filter-abyss-select-input-multi-option"
    );
    expect(ruleNameFilterOptions.length).toBe(2);
    fireEvent.click(ruleNameFilterOptions[1]);

    const flagTypeFilter = await screen.findByTestId(
      "flag-type-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(flagTypeFilter);
    fireEvent.click(flagTypeFilter);
    const flagTypeFilterOptions = await screen.findAllByTestId(
      "flag-type-filter-abyss-select-input-multi-option"
    );
    expect(flagTypeFilterOptions.length).toBe(2);
    fireEvent.click(flagTypeFilterOptions[1]);
  });
});
