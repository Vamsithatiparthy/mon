import React, { useEffect, useRef, useState } from "react";
import { useDispatch } from "react-redux";
import {
  Button,
  Checkbox,
  FormControl,
  Label,
  TextInput,
  Tooltip,
} from "@uitk/react";
import { Calendar, InfoHollow } from "@uitk/react-icons";
import moment from "moment";

import { constant } from "../../utils/constants";

import { getReportStatusCount, updateFilters } from "./evalRunSlice";

function DashboardFilter() {
  const dispatch = useDispatch();
  const initialState = {
    clientid: "",
    version: "",
    level: "",
    env: "",
    fromdate: moment(new Date().setMonth(new Date().getMonth() - 6)).format(
      "YYYY-MM-DD"
    ), // from date should be 6 month as of todays date by default
    todate: moment(new Date()).add(1, "days").format("YYYY-MM-DD"),
    readytoreview: true,
    approved: false,
    rejected: false,
    reset: false,
  };

  const [filterdata, setFilterData] = useState(initialState);
  const applyButtonRef = useRef();
  useEffect(() => {
    const enterKeyPress = (event) => {
      if (event.code === "Enter" || event.code === "NumpadEnter") {
        applyButtonRef.current.click();
      }
    };
    document.addEventListener("keydown", enterKeyPress);
    return () => {
      document.removeEventListener("keydown", enterKeyPress);
    };
  }, []);

  const maxDate = moment(new Date()).format("YYYY-MM-DD");

  const onFiltersChange = (data, checked = false) => {
    setFilterData((prevState) => ({
      ...prevState,
      [data.target.id]: checked ? data.target?.checked : data.target.value,
    }));
  };

  const applyFilter = () => {
    dispatch(updateFilters(filterdata));
  };

  const onReset = () => {
    dispatch(updateFilters(initialState));
    setFilterData(initialState);
  };

  const resetTooltip = (
    <span>
      {constant.RESET_HOVER_MSG_1}
      <br /> {constant.RESET_HOVER_MSG_2} <br />
      {constant.RESET_HOVER_MSG_3}
    </span>
  );

  return (
    <div className="filterContainer" data-testid={"test-filter"}>
      <div className="filterFields">
        <div className="inputFields">
          <FormControl id={"clientid"}>
            <Label>Client ID</Label>
            <TextInput
              data-testid="clientid-filter"
              value={filterdata.clientid}
              onChange={onFiltersChange}
            />
          </FormControl>
        </div>
        <div className="inputFields">
          <FormControl id={"env"}>
            <Label>Environment</Label>
            <TextInput
              data-testid="environment-filter"
              value={filterdata.env}
              onChange={onFiltersChange}
            />
          </FormControl>
        </div>
        <div className="inputFields">
          <FormControl id={"version"}>
            <Label>Build Value</Label>
            <TextInput
              data-testid="version-filter"
              value={filterdata.version}
              onChange={onFiltersChange}
            />
          </FormControl>
        </div>
        <div className="inputFields">
          <FormControl id={"level"}>
            <Label>Level</Label>
            <TextInput
              data-testid="level-filter"
              value={filterdata.level}
              onChange={onFiltersChange}
            />
          </FormControl>
        </div>
        <div className="dateField">
          <Label>From Date</Label>
          <div className="fromDate">
            <span className="calenderIcon">
              <Calendar className="icon" />
            </span>
            <input
              id={"fromdate"}
              data-testid="fromdate-filter"
              max={maxDate}
              value={filterdata.fromdate}
              onChange={onFiltersChange}
              type="date"
            />
          </div>
        </div>
        <div className="dateField">
          <Label>To Date</Label>
          <div className="fromDate">
            <span className="calenderIcon">
              <Calendar className="icon" />
            </span>
            <input
              id={"todate"}
              placeholder="mm-dd-yyyy"
              min={filterdata.fromdate}
              max={maxDate}
              value={filterdata.todate}
              data-testid="todate-filter"
              onChange={onFiltersChange}
              type="date"
            />
          </div>
        </div>
        <div className="applyBtn">
          <Button
            data-testid="dashboard-filter-apply-btn"
            onPress={applyFilter}
            buttonRef={applyButtonRef}
          >
            Apply
          </Button>
        </div>
        <div className="resetBtn">
          <Button
            data-testid="dashboard-filter-reset-btn"
            variant="ghost"
            onPress={onReset}
          >
            Reset
          </Button>
          <Tooltip
            className="tooltip"
            content={resetTooltip}
            placement="bottom"
          >
            <InfoHollow className="infoHollow" />
          </Tooltip>
        </div>
      </div>

      <div className="filterCheckboxes">
        <div className="checkboxField">
          <FormControl id="readytoreview">
            <Checkbox
              data-testid="readytoreview-filter"
              checked={filterdata.readytoreview}
              onChange={(e) => onFiltersChange(e, true)}
              className="readytoreview"
            >
              {constant.READY_FOR_REVIEW}
              <span className="textBold">
                {" "}
                ({getReportStatusCount()["readytoreview"]})
              </span>
            </Checkbox>
          </FormControl>
        </div>
        <div className="checkboxField">
          <FormControl id="rejected">
            <Checkbox
              data-testid="disapproved-filter"
              checked={filterdata.rejected}
              onChange={(e) => onFiltersChange(e, true)}
            >
              {constant.REJECTED}
              <span className="textBold">
                ({getReportStatusCount()["rejected"]})
              </span>
            </Checkbox>
          </FormControl>
        </div>
        <div className="checkboxField">
          <FormControl id="approved">
            <Checkbox
              data-testid="approved-filter"
              checked={filterdata.approved}
              onChange={(e) => onFiltersChange(e, true)}
            >
              {constant.APPROVED}
              <span className="textBold">
                ({getReportStatusCount()["approved"]})
              </span>
            </Checkbox>
          </FormControl>
        </div>
      </div>
    </div>
  );
}

DashboardFilter.propTypes = {};

export default DashboardFilter;
