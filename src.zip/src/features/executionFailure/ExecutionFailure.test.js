import React from "react";
import { act, fireEvent, screen, waitFor } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";
import executionFailure from "../../utils/mockdata/executionFailure.json";

import ExecutionFailure from "./ExecutionFailure";

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <ExecutionFailure evalFailures={executionFailure.eval_failures} />
      </Toolkit>
    );
  });
});

afterEach(() => {
  component.unmount();
});

describe("Renders Execution Failure Component correctly", () => {
  test("Summary component renders correctly", async () => {
    await waitFor(() => {
      expect(screen.getAllByText(/Record Details/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Actions/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Total/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/AWS/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Spark/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Unknown/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Ignored/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Marked for Rerun/i)[0]).toBeInTheDocument();
    });
  });

  test("Filter component renders correctly", async () => {
    await waitFor(() => {
      expect(
        screen.getAllByText(/DVP Execution Failure Details/i)[0]
      ).toBeInTheDocument(),
        expect(screen.getAllByText(/Filter/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Category/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Model/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Column/i)[0]).toBeInTheDocument(),
        expect(screen.getAllByText(/Reason/i)[0]).toBeInTheDocument(),
        expect(
          screen.getAllByText(/Hide Recurring Failures/i)[0]
        ).toBeInTheDocument();
    });
  });

  test("Table renders correctly", async () => {
    await waitFor(() => {
      const searchContainer = screen.getByRole("execution-failure-table");
      expect(
        screen.getAllByText(/AWS/i, { container: searchContainer })[0]
      ).toBeInTheDocument(),
        expect(
          screen.getAllByText(/Non-Recurring/i, {
            container: searchContainer,
          })[0]
        ).toBeInTheDocument(),
        expect(
          screen.getAllByText(/ALLOWED_AMT/i, { container: searchContainer })[0]
        ).toBeInTheDocument(),
        expect(
          screen.getAllByText(/ALLOWED_AMT/i, { container: searchContainer })[0]
        ).toBeInTheDocument(),
        expect(
          screen.getAllByText(
            /Exception - ApplicationError : 'DVP|Processing RATE of unique BTKs in CC_CASE_STATUS_HISTORY | Error details -Application Error/i,
            { container: searchContainer }
          )[0]
        ).toBeInTheDocument(),
        expect(
          screen.getAllByText(/Ignore/i, { container: searchContainer })[0]
        ).toBeInTheDocument(),
        expect(
          screen.getAllByText(/Mark for Rerun/i, {
            container: searchContainer,
          })[0]
        ).toBeInTheDocument();
    });
  });

  test("Select All checkbox work correctly", async () => {
    await waitFor(() => {
      fireEvent.click(screen.getByRole("execution-failure-selectall-checkbox")),
        expect(
          screen.getAllByRole("execution-failure-checkbox")[0]?.checked
        ).toBe(true);
    });
  });

  test("Category filter work correctly", async () => {
    const categoryFilter = await screen.findByTestId(
      "category-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(categoryFilter);
    const selectAWS = await screen.findAllByTestId(
      "category-filter-abyss-select-input-multi-option-checkbox"
    );
    fireEvent.click(selectAWS[1]);
    const applyBtn = await screen.findByTestId("filter-apply-btn");
    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(4);
  });

  test("Model filter work correctly", async () => {
    const modelFilter = await screen.findByTestId(
      "model-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(modelFilter);
    const selectModel = await screen.findAllByTestId(
      "model-filter-abyss-select-input-multi-option-checkbox"
    );
    fireEvent.click(selectModel[2]);
    const applyBtn = await screen.findByTestId("filter-apply-btn");
    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(8);
  });

  test("Column filter work correctly", async () => {
    const columnFilter = await screen.findByTestId(
      "column-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(columnFilter);
    const selectModel = await screen.findAllByTestId(
      "column-filter-abyss-select-input-multi-option-checkbox"
    );
    fireEvent.click(selectModel[0]);
    const applyBtn = await screen.findByTestId("filter-apply-btn");
    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    await waitFor(() => {
      expect(tableRow.length).toBe(9);
    });
  });

  test("Reason filter work correctly", async () => {
    const reasonFilter = await screen.findByTestId(
      "reason-filter-abyss-text-input"
    );
    fireEvent.change(reasonFilter, {
      target: {
        value:
          "Exception - ApplicationError : 'DVP|Processing RATE of unique BTKs in CC_CASE_STATUS'",
      },
    });
    const applyBtn = await screen.findByTestId("filter-apply-btn");
    fireEvent.click(applyBtn);
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(1);
  });

  test("Hide recurring failure filter work correctly", async () => {
    const recurringFilter = await screen.findByTestId(
      "recurring-filter-abyss-toggle-switch"
    );
    fireEvent.click(recurringFilter);
    const tableRow = await screen.findAllByTestId("table-row");
    expect(tableRow.length).toBe(2);
  });

  test("Nesed filters work correctly", async () => {
    const categoryFilter = await screen.findByTestId(
      "category-filter-abyss-select-input-multi-input"
    );
    fireEvent.click(categoryFilter);
    const selectAWS = await screen.findAllByTestId(
      "category-filter-abyss-select-input-multi-option-checkbox"
    );
    await fireEvent.click(selectAWS[1]);
    const clickModelFilter = await screen.findByTestId(
      "model-filter-abyss-select-input-multi-input"
    );
    await fireEvent.click(clickModelFilter);
    await fireEvent.click(clickModelFilter);
    const list = await screen.findByTestId(
      "model-filter-abyss-select-input-multi-option-list"
    );
    expect(list.children.length).toBe(3);
  });

  test("Action drawer components open on click", async () => {
    const actionBtn = await screen.findByTestId("execution-failure-action-btn");
    fireEvent.click(actionBtn),
      expect(screen.getByTestId("action-container")).toBeInTheDocument();
  });

  test("Table should get updated on click on apply in action drawer", async () => {
    const firstCheckbox = await screen.findByTestId(
      "execution-failure-checkbox-1"
    );
    await fireEvent.click(firstCheckbox);
    const ignoreRadioBtn = await screen.findByTestId("eval-failure-rerun-100");
    await fireEvent.click(ignoreRadioBtn);
    const applyBtn = await screen.findByTestId("action-apply-btn");
    await fireEvent.click(applyBtn);
    const markforrerun = await screen.findByTestId("eval-failure-rerun-1");
    expect(markforrerun.checked).toBe(true);
  });
});
