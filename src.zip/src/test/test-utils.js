import React from "react";
import { Provider } from "react-redux";
import { Router } from "react-router-dom";
import { setupListeners } from "@reduxjs/toolkit/dist/query";
import { render as rtlRender } from "@testing-library/react";
import { createMemoryHistory } from "history";

import { setupStore } from "../app/store";

export function renderWithProviders(
  ui,
  {
    route = "/dashboard/report/application_1665070856320_0004_20221006161512",
    history = createMemoryHistory({ initialEntries: [route] }),
    preloadedState = {},
    store = setupStore(preloadedState),
  } = {}
) {
  setupListeners(store.dispatch);
  return {
    ...rtlRender(
      <Provider store={store}>
        <Router history={history}>{ui}</Router>
      </Provider>
    ),
    history,
    store,
  };
}
