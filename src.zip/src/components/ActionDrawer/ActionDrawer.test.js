import React from "react";
import { screen } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";

import ActionDrawer from "./ActionDrawer";

function getContent() {
  return <div>Hello, world!</div>;
}

describe("Renders ActionDrawer Component correctly", () => {
  test("Renders ActionDrawer Component correctly", async () => {
    let component = renderWithProviders(
      <Toolkit>
        <ActionDrawer
          open={false}
          content={getContent}
          checkedCount={10}
          disabled={true}
          mixedValue={false}
          actionBtnHeight={200}
        />
      </Toolkit>
    );
    expect(screen.queryByTestId("action-drawer")).not.toBeInTheDocument();
    component.unmount();
  });

  test("Renders ActionDrawer Component when open is true", async () => {
    let component = renderWithProviders(
      <Toolkit>
        <ActionDrawer
          open={true}
          content={getContent}
          checkedCount={10}
          disabled={true}
          mixedValue={false}
          actionBtnHeight={200}
        />
      </Toolkit>
    );
    expect(screen.queryByTestId("action-drawer")).toBeInTheDocument();
    component.unmount();
  });

  test("Renders ActionDrawer content correctly", async () => {
    let component = renderWithProviders(
      <Toolkit>
        <ActionDrawer
          open={true}
          content={getContent}
          checkedCount={10}
          disabled={true}
          mixedValue={false}
          actionBtnHeight={200}
        />
      </Toolkit>
    );
    expect(screen.queryByText("Hello, world!")).toBeInTheDocument();
    component.unmount();
  });

  test("ActionDrawer Buttons should be disabled if disabled prop is true", async () => {
    let component = renderWithProviders(
      <Toolkit>
        <ActionDrawer
          open={true}
          content={getContent}
          checkedCount={10}
          disabled={true}
          mixedValue={false}
          actionBtnHeight={200}
        />
      </Toolkit>
    );
    const applyBtn = await screen.findByTestId("action-apply-btn");
    const cancelBtn = await screen.findByTestId("action-apply-btn");
    console.log(applyBtn);
    expect(applyBtn.disabled).toBe(true);
    expect(cancelBtn.disabled).toBe(true);
    component.unmount();
  });

  test("Mixed value warning should be displayed if mixedValue prop is true", async () => {
    let component = renderWithProviders(
      <Toolkit>
        <ActionDrawer
          open={true}
          content={getContent}
          checkedCount={10}
          disabled={true}
          mixedValue={true}
          actionBtnHeight={200}
        />
      </Toolkit>
    );
    expect(screen.queryByTestId("mixed-value")).toBeInTheDocument();
    component.unmount();
  });
});
