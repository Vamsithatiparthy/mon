import React from "react";
import { useParams } from "react-router-dom";
import { act, fireEvent, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";

import EvalReport from "./EvalReport";

jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useParams: jest.fn(),
}));
const mockParams = { evalId: "123" };
useParams.mockReturnValue(mockParams);

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <EvalReport />
      </Toolkit>
    );
  });
});

afterEach(() => {
  component.unmount();
});

describe("Renders Eval Report Component correctly", () => {
  test("Renders Client Details correctly", async () => {
    waitFor(() => {
      expect(screen.getAllByText(/H704847/i)[0]).toBeInTheDocument();
      expect(screen.getAllByText(/202006/i)[0]).toBeInTheDocument();
      expect(screen.getAllByText(/1/i)[0]).toBeInTheDocument();
      expect(screen.getAllByText(/CDR_BE/i)[0]).toBeInTheDocument();
    });
  });

  test("Renders Tooltip Details correctly", async () => {
    await waitFor(() => {
      userEvent.click(screen.getByText(/More Info/i));
    });

    await waitFor(() => {
      // expect(
      //   screen.getAllByText(
      //     /Source DB:h704847_data_quality_dev_srd_cdr_be_202006/i
      //   )[0]
      // ).toBeInTheDocument();
      // expect(
      //   screen.getAllByText(
      //     /Previous Source DB:h704847_data_quality_dev_srd_cdr_be_202005/i
      //   )[0]
      // ).toBeInTheDocument();
      expect(
        screen.getAllByText(/Report Generated On:/i)[0]
      ).toBeInTheDocument();
      expect(
        screen.getAllByText(
          /Eval Run Id:application_1657584717681_0004_2022071f20139409/i
        )[0]
      ).toBeInTheDocument();
    });
  });

  test("Wizard displays correctly", async () => {
    await waitFor(() => {
      expect(
        screen.getAllByText(/DVP Execution Failure/i)[0]
      ).toBeInTheDocument(),
        expect(screen.getAllByText(/Analyse Charts/i)[0]).toBeInTheDocument();
      // Uncomment below line once QC page is developed
      // expect(screen.getAllByText(/QC Signoff/i)[0]).toBeInTheDocument();
    });
  });

  test("Update and save changes", async () => {
    const saveChangeBtn = await screen.findByRole("button", {
      name: /Save Changes/i,
    });
    await waitFor(async () => {
      expect(saveChangeBtn).toBeDisabled();
      const actionRadioButton = screen.getAllByText(/Mark For Rerun/i)[0];
      fireEvent.click(actionRadioButton), expect(saveChangeBtn).toBeEnabled();
      fireEvent.click(saveChangeBtn);
    });

    await waitFor(() => expect(saveChangeBtn).toBeDisabled());
  });

  // Uncomment below test case when filling all failure actions is mandatory
  // test("Show validation error on step progress", async () => {
  //   let wizardStep = await screen.findByText(/Analyse Charts/i);
  //   expect(wizardStep).toBeInTheDocument();
  //   fireEvent.click(wizardStep);
  //   expect(
  //     screen.getByText(
  //       /Fill action for DVP Execution Failure to proceed to Analyse Charts/
  //     )
  //   ).toBeInTheDocument();
  //   // Uncomment below lines once QC page is developed
  //   // wizardStep = await screen.findByText(/QC Signoff/i);
  //   // fireEvent.click(wizardStep);
  //   // expect(
  //   //   screen.getByText(
  //   //     /Fill action for DVP Execution Failure and Analyse Charts to proceed to QC Signoff/
  //   //   )
  //   // ).toBeInTheDocument();
  //   const groupFields = screen.getAllByRole("group");
  //   expect(groupFields[2]).toHaveClass("error");

  //   const saveChangeBtn = await screen.findByRole("button", {
  //     name: /Save Changes/i,
  //   });
  //   await waitFor(async () => {
  //     const actionRadioButton = screen.getAllByText(/Mark For Rerun/i)[2];
  //     fireEvent.click(actionRadioButton), expect(saveChangeBtn).toBeEnabled();
  //   });
  //   // Uncomment below lines once QC page is developed
  //   // fireEvent.click(wizardStep);
  //   // expect(
  //   //   screen.getByText(/Save changes to proceed to QC Signoff/)
  //   // ).toBeInTheDocument();

  //   // fireEvent.click(saveChangeBtn),
  //   //   await waitFor(() => expect(saveChangeBtn).toBeDisabled());
  //   // fireEvent.click(wizardStep);
  //   // expect(screen.queryByText(/Mark For Rerun/i)).toBeNull();
  // });

  // Uncomment below lines once QC page is developed
  // test("Navigate steps through next prev button", async () => {
  //   const nextBtn = await screen.findByRole("button", {
  //     name: /Next >/i,
  //   });
  //   expect(nextBtn).toBeDisabled();

  //   const saveChangeBtn = await screen.findByRole("button", {
  //     name: /Save Changes/i,
  //   });
  //   await waitFor(async () => {
  //     const actionRadioButton = screen.getAllByText(/Mark For Rerun/i)[2];
  //     fireEvent.click(actionRadioButton), expect(saveChangeBtn).toBeEnabled();
  //   });

  //   fireEvent.click(saveChangeBtn),
  //     await waitFor(() => expect(nextBtn).toBeEnabled());

  //   fireEvent.click(nextBtn);
  //   const prevBtn = await screen.findByRole("button", {
  //     name: /< Prev/i,
  //   });
  //   expect(prevBtn).toBeInTheDocument();

  //   fireEvent.click(prevBtn);
  //   expect(screen.queryByText(/< Prev/i)).toBeNull();
  // });
});
