import { rest } from "msw";

import { constant } from "../../utils/constants";
import analyseChartEvalResult from "../../utils/mockdata/analyseChartEvalResult";
import { ruleTypeFilter } from "../../utils/mockdata/analyseChartRootFilters";
import contentCheckRecords from "../../utils/mockdata/contentCheckMockdata.json";
import dashboardTableData from "../../utils/mockdata/dashboardMockdata";
import evalRunDetails from "../../utils/mockdata/evalReport";
import executionFailureMockdata from "../../utils/mockdata/executionFailure.json";
import userMockData from "../../utils/mockdata/userDetails";

const baseUrl = "http://localhost:3000/api";
const isIdle = {
  isIdle: false,
};
const cdnUrl = {
  cdnUrl: "https://d1vvi2df1hxdp6.cloudfront.net",
};
const handlers = [
  rest.get(`${baseUrl}/isidle`, (req, res, ctx) => {
    return res(ctx.json(isIdle));
  }),
  rest.get(`${baseUrl}/reportBaseUrl`, (req, res, ctx) => {
    return res(ctx.json(cdnUrl));
  }),
  rest.get(`${baseUrl}/user`, (req, res, ctx) => {
    return res(ctx.json(userMockData));
  }),
  rest.get(`${baseUrl}/dvp?type=${constant.EVAL_RUN}`, (req, res, ctx) => {
    return res(ctx.json(dashboardTableData));
  }),
  rest.get(`${baseUrl}/${constant.EVAL_RUN}/:id`, (req, res, ctx) => {
    return res(ctx.json(evalRunDetails));
  }),
  rest.get(
    `${baseUrl}/eval_run/:id/${constant.EVAL_FAILURES}`,
    (req, res, ctx) => {
      return res(ctx.json(executionFailureMockdata.eval_failures));
    }
  ),
  rest.patch(
    `${baseUrl}/eval_run/:id/${constant.EVAL_FAILURES}`,
    (req, res, ctx) => {
      return res(ctx.json({ success: true }));
    }
  ),
  rest.get("*/abyss/*", (req, res, ctx) => {
    return res(ctx.status(200), ctx.json({ message: "mock for abyss" }));
  }),
  rest.get(`${baseUrl}/${constant.CONTENT_CHECK_API}/:id`, (req, res, ctx) => {
    return res(ctx.json(contentCheckRecords));
  }),
  rest.get(
    `${baseUrl}/${constant.EVAL_RUN}/:id/${constant.ROOT_FILTER}`,
    (req, res, ctx) => {
      return res(ctx.json(ruleTypeFilter));
    }
  ),
  rest.post(
    `${baseUrl}/${constant.EVAL_RUN}/:id/${constant.EVAL_RESULT}/search`,
    (req, res, ctx) => {
      return res(ctx.json(analyseChartEvalResult));
    }
  ),
  rest.get("*", (req, res, ctx) => {
    console.error(`Please add request handler for ${req.url.toString()}`);
    return res(
      ctx.status(500),
      ctx.json({ error: "You must add request handler." })
    );
  }),
];

export { handlers };
