import React, { Suspense, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useLocation } from "react-router-dom/cjs/react-router-dom.min";
import { useToast } from "@abyss/web/hooks/useToast";
import { LoadingIndicator } from "@uitk/react";

import { useGetUserDetailsQuery } from "../../components/header/HeaderApiSlice";
import { navigationTabs, toastConstants } from "../../utils/constants";
import { useSetThresholdMutation } from "../contentCheck/contentCheckApiSlice";
import { useGetDataQuery } from "../dashboard/evalRunApiSlice";
import { useSetQcStatusMutation } from "../evalReport/evalReportApiSlice";

import SummaryTab from "./SummaryTab";
const EvalRunData = React.lazy(() => import("./EvalRunData"));
const ReportStatusBar = React.lazy(() => import("./ReportStatusBar"));
const TabMenu = React.lazy(() => import("./TabMenu"));
const ContentCheck = React.lazy(() => import("../contentCheck/ContentCheck"));
const EvalReport = React.lazy(() => import("../evalReport/EvalReport"));
const Modal = React.lazy(() => import("./Modal"));

function Results() {
  const { toast } = useToast();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const source = params.get("source");
  console.log("Source of the request:", source);
  const [activeTab, setActiveTab] = useState(
    source === "overview"
      ? navigationTabs.SUMMARY
      : navigationTabs.CONTENT_CHECK_RESULTS
  );
  const [openModal, setOpenModal] = useState(false);
  const [notes, setNotes] = useState("");
  const [setQcStatus] = useSetQcStatusMutation();
  const [setThreshold] = useSetThresholdMutation();
  const [modalType, setModalType] = useState("");
  const [newNavItems, setNewNavItems] = useState([]);
  const [evalRunData, setEvalRunData] = useState({});
  const [currentCcDataVersion, setCurrentCcDataVersion] = useState("");
  const [currentAiDataVersion, setCurrentAiDataVersion] = useState("");
  const handleEvalData = (data) => {
    setEvalRunData(data);
  };
  /*
  this useEffect is used to update the navigation tabs based on the data received from the API.
  It populates the tab data for AI Check Results and Content Check Results and sets the latest data version for each tab.
  */
  useEffect(() => {
    if (Object.keys(evalRunData).length > 0) {
      let navItems = [];

      if (Object.keys(evalRunData.eval_runs.cc).length > 0) {
        if (source === "overview") {
          navItems.push({
            title: navigationTabs.SUMMARY,
            options: evalRunData.eval_runs.cc.map((item) => item.dataVersion),
          });
        }
        navItems.push({
          title: navigationTabs.CONTENT_CHECK_RESULTS,
          options: evalRunData.eval_runs.cc.map((item) => item.dataVersion),
        });
        if (source === "overview") {
          navItems.push({
            title: navigationTabs.AI_CHECK_RESULTS,
            options: evalRunData.eval_runs.cc.map((item) => item.dataVersion),
          });
        }
        let index = 0;
        evalRunData.eval_runs.cc.forEach((item, i) => {
          if (item.dataVersion > evalRunData.eval_runs.cc[index].dataVersion) {
            index = i;
          }
        });
        const latestDataVersion = evalRunData.eval_runs.cc[index].dataVersion;
        setCurrentCcDataVersion(latestDataVersion);
      }

      if (Object.keys(evalRunData.eval_runs.ai).length > 0) {
        navItems.push({
          title: navigationTabs.AI_CHECK_RESULTS,
          options: evalRunData.eval_runs.ai.map((item) => item.dataVersion),
        });
        let index = 0;
        evalRunData.eval_runs.ai.forEach((item, i) => {
          if (item.dataVersion > evalRunData.eval_runs.ai[index].dataVersion) {
            index = i;
          }
        });
        const latestEvalId = evalRunData.eval_runs.ai[index].dataVersion;
        setCurrentAiDataVersion(latestEvalId);
        if (Object.keys(evalRunData.eval_runs.cc).length === 0)
          setActiveTab(navigationTabs.AI_CHECK_RESULTS);
      }

      if (navItems.length > 0) {
        navItems.forEach((navItem) => {
          navItem?.options?.sort((a, b) => b.localeCompare(a));
        });
      }

      setNewNavItems(navItems);
    }
  }, [evalRunData]);

  const handleDataVersion = (tab, data) => {
    setActiveTab(tab);
    if (tab === navigationTabs.AI_CHECK_RESULTS) setCurrentAiDataVersion(data);
    if (tab === navigationTabs.CONTENT_CHECK_RESULTS)
      setCurrentCcDataVersion(data);
  };

  const updateQcStatus = async (action) => {
    const dvp_run_id = evalRunData.dvp_run_id;
    const response = await setQcStatus({
      dvp_run_id: dvp_run_id,
      qcStatus: action,
    });
    if (response) {
      if (response.error?.data?.message != undefined) {
        toast.show({
          title: response.error?.data?.message,
          variant: toastConstants.ERROR,
        });
      }
      if (response?.data?.message != undefined) {
        toast.show({
          title: response.data.message,
          variant: toastConstants.SUCCESS,
          onClose: () => {
            window.location.reload();
          },
        });
      }
    }
    setOpenModal(false);
  };

  const handleTabChange = (activeTab) => {
    setActiveTab(activeTab);
  };

  const onChangeHandler = (e) => {
    e.preventDefault();
    setNotes(e.target.value);
  };

  const closeModal = () => {
    setOpenModal(false);
  };

  const openModalHandler = (type) => {
    setModalType(type);
    setOpenModal(true);
  };

  const { clientId, env, level, version } = useParams();
  const { data, isLoading, error } = useGetDataQuery({
    clientId,
    env,
    level,
    version,
  });

  const { data: userDetails } = useGetUserDetailsQuery();
  const currentUser = userDetails?.firstName;

  return (
    <>
      {error &&
        toast.show({
          title: toastConstants.EVAL_RUN_NOT_FOUND,
          type: toastConstants.ERROR,
        })}
      {isLoading && (
        <LoadingIndicator
          size="l"
          loading={isLoading}
          centerSpinner={true}
          className="loader"
        />
      )}
      {!isLoading && !data && (
        <p className="loader">eval run details not found</p>
      )}

      <div className="results">
        {Object.keys(evalRunData).length === 0 && (
          <EvalRunData handleEvalData={handleEvalData} />
        )}
        {Object.keys(evalRunData).length > 0 && (
          <>
            <Suspense
              fallback={
                <LoadingIndicator
                  size="l"
                  centerSpinner={true}
                  className="loader"
                />
              }
            >
              <ReportStatusBar
                currentEvalRunData={evalRunData}
                openModalHandler={openModalHandler}
                tab={activeTab}
                dataVersion={
                  activeTab === navigationTabs.CONTENT_CHECK_RESULTS
                    ? currentCcDataVersion
                    : currentAiDataVersion
                }
              />
              <TabMenu
                navItems={newNavItems}
                activeTab={activeTab}
                handleTabChange={handleTabChange}
                handleDataVersion={handleDataVersion}
              />
              <Modal
                openModal={openModal}
                currentUser={currentUser}
                closeModal={closeModal}
                modalType={modalType}
                onChangeHandler={onChangeHandler}
                notes={notes}
                updateQcStatus={updateQcStatus}
                setThreshold={setThreshold}
                currentCcDataVersion={currentCcDataVersion}
                evalRunData={evalRunData}
              />
              {activeTab === navigationTabs.CONTENT_CHECK_RESULTS &&
                currentCcDataVersion !== "" && (
                  <Suspense
                    fallback={
                      <LoadingIndicator size="l" centerSpinner={true} />
                    }
                  >
                    <ContentCheck
                      data={evalRunData}
                      currentDataVersion={currentCcDataVersion}
                    />
                  </Suspense>
                )}
              {activeTab === navigationTabs.AI_CHECK_RESULTS &&
                currentAiDataVersion !== "" && (
                  <Suspense
                    fallback={
                      <LoadingIndicator size="l" centerSpinner={true} />
                    }
                  >
                    <EvalReport
                      report_details={evalRunData}
                      currentDataVersion={currentAiDataVersion}
                    />
                  </Suspense>
                )}
              {activeTab === navigationTabs.SUMMARY && (
                <Suspense
                  fallback={<LoadingIndicator size="l" centerSpinner={true} />}
                >
                  <SummaryTab />
                </Suspense>
              )}
            </Suspense>
          </>
        )}
      </div>
    </>
  );
}
export default Results;
