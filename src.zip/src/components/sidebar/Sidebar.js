import { Navigation, NavType } from "@uitk/react";
import {
  ArrowDown,
  ArrowUp,
  Document,
  Guidelines,
  HelpHollow,
  NewWindow,
  Results,
  Overview,
} from "@uitk/react-icons";

import { RoutableLink } from "../../utils/common";
import { constant } from "../../utils/constants";

const useCurrentRoute = () => {
  const location = window.location.pathname + window.location.search;
  return location;
};

function Sidebar() {
  const overview = {
    label: "Overview",
    url: "/dashboard?view=overview",
    icon: <Overview customSize="24px" />,
  };
  const dashboard = {
    label: "Reports",
    url: "/dashboard?view=reports",
    icon: <Results customSize="24px" />,
  };
  // const rules = {
  //   label: <span id="write-rules">Write Rules</span>,
  //   url: "/rules",
  //   icon: <Edit customSize="24px" />,
  // };
  const help = {
    label: "Help",
    icon: <HelpHollow customSize="24px" />,
    links: [
      {
        label: (
          <>
            About DVP
            <br />
            <NewWindow />
          </>
        ),
        url: constant.DVP_DOCS_URL,
        target: "_blank",
        icon: (
          <>
            <Guidelines customSize="24px" />
          </>
        ),
      },
      {
        label: (
          <>
            User Guide
            <br />
            <NewWindow />
          </>
        ),
        target: "_blank",
        url: constant.DVP_USER_GUIDE_URL,
        icon: (
          <>
            <Document customSize="24px" />
          </>
        ),
      },
    ],
  };
  //const navigationLink = [dashboard, rules, help];
  const navigationLink = [overview, dashboard, help];
  const verticalNavigationConfig = {
    linkAs: RoutableLink,
    links: navigationLink,
    panelExpandedIcon: <ArrowUp />,
    panelClosedIcon: <ArrowDown />,
  };

  return (
    <div className={"sidebar"} data-testid="sidebar">
      <Navigation
        useLocation={useCurrentRoute}
        className="vertical-navigation"
        variant={NavType.VERTICAL}
        config={verticalNavigationConfig}
      />
    </div>
  );
}

export default Sidebar;
