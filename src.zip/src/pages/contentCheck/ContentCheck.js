import { useCallback, useEffect, useState } from "react";
import { useMediaQuery } from "react-responsive";
import { useToast } from "@abyss/web/hooks/useToast";
import { Badge } from "@abyss/web/ui/Badge";
import { Checkbox } from "@abyss/web/ui/Checkbox";
import { DropdownMenu } from "@abyss/web/ui/DropdownMenu";
import { Icon } from "@abyss/web/ui/Icon";
import { IconSymbol } from "@abyss/web/ui/IconSymbol";
import { Popover } from "@abyss/web/ui/Popover";
import { RadioGroup } from "@abyss/web/ui/RadioGroup";
import { SelectInputMulti } from "@abyss/web/ui/SelectInputMulti";
import { TextInput } from "@abyss/web/ui/TextInput";
import {
  Button,
  Label,
  LoadingIndicator,
  Pagination,
  Table,
  Tooltip,
} from "@uitk/react";
import { InfoFilled } from "@uitk/react-icons";
import PropTypes from "prop-types";

import menuIcon from "../../assets/menuIcon.svg";
import {
  containsString,
  generateAndDownloadCSV,
  getFilterOptions,
} from "../../utils/common";
import { constant, toastConstants } from "../../utils/constants";

import { useGetContentCheckRecordsQuery } from "./contentCheckApiSlice";
import {
  addZoomClass,
  checkboxes,
  entriesPerPageConfig,
  getZoomLevel,
  renderCells,
} from "./utils";

function ContentCheck({ data: evalRunData, currentDataVersion }) {
  const { toast } = useToast();
  const { client, env, level, version } = evalRunData;
  const {
    data: contentChecks,
    isLoading,
    error,
  } = useGetContentCheckRecordsQuery({
    clientId: client,
    env: env,
    level: level,
    version: version,
    dataVersion: currentDataVersion,
  });

  const isTabletOrMobile = useMediaQuery({ query: "(max-width: 1224px)" });
  const [tableData, setTableData] = useState([]);
  const [nestedTableData, setNestedTableData] = useState([]);
  const [contentCheckFilters, setContentCheckFilters] = useState({
    view_name: [],
    check_name: [],
    bad_rows_from: 0,
    bad_rows_to: 100,
    check_tags: [],
    check_quality_dimension: [],
    check_criticality: [],
    displayChecks: "anomaly",
  });
  const [page, setPage] = useState(1);
  const [displayShowFields, setDisplayShowFields] = useState(false);
  const [collapseAll, setCollapseAll] = useState(true);
  // used to toggle all dropdown buttons to expand or collapse
  useEffect(() => {
    if (collapseAll) {
      const expandButtons = document.querySelectorAll(".iLnYcW");
      expandButtons.forEach((button) => {
        button.click();
      });
    } else {
      const expandButtons = document.querySelectorAll(".PayKI");
      expandButtons.forEach((button) => {
        button.click();
      });
    }
  }, [collapseAll]);

  useEffect(() => {
    if (contentChecks) {
      let nestedTableData = {};
      for (const element in contentChecks.nestedTableData) {
        const data = contentChecks.nestedTableData[element];
        const filteredData = data.filter(
          (element) => !element.accept || element.is_core_check
        );
        nestedTableData[element] = filteredData;
      }
      // filter the records which has some data as nested table
      const tableData = contentChecks.tableData.filter((element) => {
        return nestedTableData[element.view_name].length > 0;
      });
      setTableData(tableData);
      setNestedTableData(nestedTableData);
      applyFilters();
    }
  }, [contentChecks]);

  useEffect(() => {
    setPage(1);
  }, [tableData]);

  const setContentCheckFiltersState = (filterType, value) => {
    setContentCheckFilters((prevState) => ({
      ...prevState,
      [filterType]: value,
    }));
  };

  const onPageChange = (page) => {
    setPage(page);
  };

  const [displayFields, setDisplayFields] = useState(checkboxes);
  const [tempFields, setTempFields] = useState(displayFields);

  const handleApply = () => {
    setDisplayFields(tempFields);
    setCollapseAll(false);
    setDisplayShowFields(false);
  };

  const handleCancel = () => {
    setTempFields(displayFields);
    setDisplayShowFields(false);
  };

  const handleCheckboxChange = (field) => (e) => {
    setTempFields(() => {
      return tempFields.map((f) => {
        if (f.value === field) {
          return { ...f, isChecked: e.target.checked };
        }
        return f;
      });
    });
  };

  const getIsChecked = (fields, field) => {
    const fieldObj = fields.find((f) => f.value === field);
    return fieldObj?.isChecked;
  };

  const fieldsOptions = (
    <>
      <Label style={{ paddingBottom: "10px" }}>Select fields</Label>
      {displayFields.map((field) => (
        <Checkbox
          size="sm"
          key={field.value}
          label={field.label}
          value={field.value}
          isChecked={getIsChecked(tempFields, field.value)}
          isDisabled={field.isDisabled}
          onChange={handleCheckboxChange(field.value)}
        />
      ))}
      <br />
      <div style={{ display: "flex", gap: "10px" }}>
        <Button
          type="button"
          size="s"
          style={{ marginTop: 16 }}
          onClick={handleApply}
        >
          Apply
        </Button>
        <Button type="button" size="s" onClick={handleCancel}>
          Cancel
        </Button>
      </div>
    </>
  );

  const getExpandableRows = () => {
    let rows = {};
    for (const element in nestedTableData) {
      rows[element] = {
        content: (
          <Table
            id={"nested-table"}
            data-testid="nested-table"
            data={nestedTableData[element]}
            config={nestedConfig}
            className="content-check-nested-table"
          />
        ),
        removePadding: true,
        altHideRowButtonText: "Collapse Row",
      };
    }
    return rows;
  };

  window.onresize = function () {
    var currentZoomLevel = getZoomLevel();
    addZoomClass(currentZoomLevel);
  };

  const getFilterValues = useCallback(
    (key) => {
      const filtersClone = { ...contentCheckFilters };
      // deleting below these two fields because these fields are not dropdown fields.
      delete filtersClone["bad_rows_from"];
      delete filtersClone["bad_rows_to"];
      delete filtersClone["displayChecks"];
      return getFilterOptions(
        key,
        filtersClone,
        contentChecks.dataset_check_summary
      );
    },
    [
      contentCheckFilters.check_name,
      contentCheckFilters.view_name,
      contentChecks,
    ]
  );

  const getBadRowsCount = (data) => {
    const badRowsCount = data.filter((element) => element.bad_rows > 0);
    return badRowsCount.length;
  };

  const applyFilters = () => {
    const data = contentChecks.tableData;
    const {
      view_name,
      check_name,
      bad_rows_from,
      bad_rows_to,
      displayChecks,
      check_quality_dimension,
      check_criticality,
      check_tags,
    } = contentCheckFilters;
    // validation for bad rows range
    if (bad_rows_from < 0 || bad_rows_to > 100) {
      toast.show({
        title: toastConstants.BAD_ROWS_RANGE,
        type: toastConstants.ERROR,
      });
      return;
    } else if (bad_rows_from > bad_rows_to) {
      toast.show({
        title: toastConstants.BAD_ROWS_FROM_GREATER_THAN_TO,
        type: toastConstants.ERROR,
      });
      return;
    }
    let nestedTableFilteredData = {};
    let currNestedTableFilteredData = {};
    let filteredData = data.filter((table_element) => {
      for (const key in contentChecks.nestedTableData) {
        const records = contentChecks.nestedTableData[key].filter((element) => {
          const checkNameFilter =
            check_name.length != 0
              ? containsString([...check_name], element["check_name"])
              : true;

          var criticalityFilter = true;
          if (check_criticality.length !== 0) {
            if (element["check_criticality"] !== null) {
              criticalityFilter = containsString(
                [...check_criticality],
                element["check_criticality"]
              );
            } else {
              criticalityFilter = false;
            }
          }

          // check if the tags are present in the element
          let checkTagsFilter = true;
          if (check_tags && check_tags.length > 0) {
            checkTagsFilter = check_tags.every((tag) => {
              tag = JSON.parse(tag);
              return Object.entries(tag).every(([key, value]) => {
                return element["check_tags"][key] === value;
              });
            });
          }

          // check if the quality dimensions are present in the element array or not
          const qualityDimensionsFilter =
            check_quality_dimension.length != 0
              ? check_quality_dimension.every((qd) =>
                  containsString(element["check_quality_dimension"], qd)
                )
              : true;

          const badRowFilter =
            element["bad_row_percent"] >= parseInt(bad_rows_from) &&
            element["bad_row_percent"] <= parseInt(bad_rows_to);

          // check conditions for displayChecks
          if (displayChecks === "anomaly") {
            return (
              checkNameFilter &&
              badRowFilter &&
              qualityDimensionsFilter &&
              checkTagsFilter &&
              criticalityFilter &&
              (!element.accept || element.is_core_check)
            );
          } else if (displayChecks === "core") {
            return (
              checkNameFilter &&
              badRowFilter &&
              qualityDimensionsFilter &&
              checkTagsFilter &&
              criticalityFilter &&
              element.is_core_check
            );
          } else {
            return (
              checkNameFilter &&
              badRowFilter &&
              qualityDimensionsFilter &&
              checkTagsFilter &&
              criticalityFilter
            );
          }
        });
        nestedTableFilteredData[key] = records;
        const filteredRecord = records.filter((record) => {
          return displayChecks === "all"
            ? true
            : Object.keys(record).length > 0;
        });
        currNestedTableFilteredData[key] = filteredRecord;
      }
      const viewNameFilter =
        view_name.length != 0
          ? containsString([...view_name], table_element["view_name"])
          : true;
      return viewNameFilter;
    });
    const updateCheckCount = filteredData.map((element) => {
      return {
        ...element,
        check_count: nestedTableFilteredData[element.view_name].length,
        bad_rows_count: getBadRowsCount(
          nestedTableFilteredData[element.view_name]
        ),
      };
    });
    const updateAnomaly = updateCheckCount.filter((element) => {
      return currNestedTableFilteredData[element.view_name].length > 0;
    });
    // close all expanded rows
    const expandButtons = document.querySelectorAll(".iLnYcW");
    expandButtons.forEach((button) => {
      button.click();
    });
    setCollapseAll(true);
    setTableData(updateAnomaly);
    setNestedTableData(currNestedTableFilteredData);
  };
  useEffect(() => {
    const check_severity_btns = document.querySelectorAll(".anomaly");
    if (check_severity_btns.length > 0) {
      check_severity_btns.forEach((btn) => {
        const parentTd = btn.parentElement.parentElement;
        parentTd.classList.add("anomaly-severity");
      });
    }
  }, [tableData, nestedTableData]);

  const applyFiltersCsv = () => {
    const data = contentChecks.dataset_summary;
    const {
      view_name,
      check_name,
      bad_rows_from,
      bad_rows_to,
      displayChecks,
      check_quality_dimension,
      check_criticality,
      check_tags,
    } = contentCheckFilters;
    let temp_filtered_dataset_check_summary = [];
    let filtered_dataset_check_summary = [];
    let filtered_dataset_summary = data.filter((table_element) => {
      const records = contentChecks.dataset_check_summary.filter((element) => {
        const viewNameFilter =
          view_name.length != 0
            ? containsString([...view_name], element["view_name"])
            : true;

        const checkNameFilter =
          check_name.length != 0
            ? containsString([...check_name], element["check_name"])
            : true;

        var criticalityFilter = true;
        if (check_criticality.length !== 0) {
          if (element["check_criticality"] !== null) {
            criticalityFilter = containsString(
              [...check_criticality],
              element["check_criticality"]
            );
          } else {
            criticalityFilter = false;
          }
        }

        const qualityDimensionsFilter =
          check_quality_dimension.length != 0
            ? check_quality_dimension.every((qd) =>
                containsString(element["check_quality_dimension"], qd)
              )
            : true;

        let checkTagsFilter = true;
        if (check_tags && check_tags.length > 0) {
          checkTagsFilter = check_tags.every((tag) => {
            tag = JSON.parse(tag);
            return Object.entries(tag).every(([key, value]) => {
              if (Array.isArray(element["check_tags"][key])) {
                return element["check_tags"][key].includes(value);
              } else {
                return element["check_tags"][key] === value;
              }
            });
          });
        }

        const badRowFilter =
          element["bad_row_percent"] >= parseInt(bad_rows_from) &&
          element["bad_row_percent"] <= parseInt(bad_rows_to);

        // check conditions for displayChecks
        if (displayChecks === "anomaly") {
          return (
            checkNameFilter &&
            viewNameFilter &&
            badRowFilter &&
            qualityDimensionsFilter &&
            checkTagsFilter &&
            criticalityFilter &&
            (!element.accept || element.is_core_check)
          );
        } else if (displayChecks === "core") {
          return (
            checkNameFilter &&
            viewNameFilter &&
            badRowFilter &&
            qualityDimensionsFilter &&
            checkTagsFilter &&
            criticalityFilter &&
            element.is_core_check
          );
        } else {
          return (
            checkNameFilter &&
            viewNameFilter &&
            badRowFilter &&
            qualityDimensionsFilter &&
            checkTagsFilter &&
            criticalityFilter
          );
        }
      });
      temp_filtered_dataset_check_summary.push(records);
      const filteredRecord = records.filter((record) => {
        return displayChecks === "all" ? true : Object.keys(record).length > 0;
      });
      filtered_dataset_check_summary.push(...filteredRecord);

      const viewNameFilter =
        view_name.length != 0
          ? containsString([...view_name], table_element["view_name"])
          : true;
      return viewNameFilter;
    });

    // remove duplicates from filtered_dataset_check_summary
    filtered_dataset_check_summary = filtered_dataset_check_summary.filter(
      (v, i, a) =>
        a.findIndex(
          (t) =>
            t.view_name === v.view_name &&
            t.check_name === v.check_name &&
            t.column_name === v.column_name
        ) === i
    );

    filtered_dataset_summary = filtered_dataset_summary.filter((element) => {
      return (
        filtered_dataset_check_summary.filter(
          (record) => record.view_name === element.view_name
        ).length > 0
      );
    });

    return { filtered_dataset_summary, filtered_dataset_check_summary };
  };

  const onReset = () => {
    setContentCheckFilters({
      view_name: [],
      check_name: [],
      check_quality_dimension: [],
      check_criticality: [],
      check_tags: [],
      displayChecks: "anomaly",
      bad_rows_from: 0,
      bad_rows_to: 100,
    });
    // reset the table to have anomaly and core checks only
    let nestedTableData = {};
    for (const element in contentChecks.nestedTableData) {
      let data = contentChecks.nestedTableData[element];
      const filteredData = data.filter(
        (element) => !element.accept || element.is_core_check
      );
      nestedTableData[element] = filteredData;
    }
    // show only the records which has some data as nested table
    const tableData = contentChecks.tableData.filter((element) => {
      return nestedTableData[element.view_name].length > 0;
    });
    // close all expanded rows
    const expandButtons = document.querySelectorAll(".iLnYcW");
    expandButtons.forEach((button) => {
      button.click();
    });
    setCollapseAll(true);
    setTableData(tableData);
    setNestedTableData(nestedTableData);
  };

  const getContentCheckFilters = () => {
    return (
      <div
        className="content-check-filter-container"
        style={{ margin: "5px 24px" }}
      >
        <div className="content-check-filter-content">
          <div className="content-check-filter-options">
            <div className="content-check-form-multi-select">
              <SelectInputMulti
                label="View Name"
                placeholder="Select"
                isSearchable
                hideChips
                enableOutsideScroll
                value={contentCheckFilters.view_name}
                onChange={(value) => {
                  setContentCheckFiltersState("view_name", value);
                }}
                selectAll
                options={getFilterValues("view_name")}
                data-testid="view-name-filter"
              />
            </div>
            <div className="content-check-form-multi-select">
              <SelectInputMulti
                label="Check Name"
                placeholder="Select"
                isSearchable
                hideChips
                value={contentCheckFilters.check_name}
                onChange={(value) =>
                  setContentCheckFiltersState("check_name", value)
                }
                enableOutsideScroll
                selectAll
                options={getFilterValues("check_name")}
                data-testid="check-name-filter"
              />
            </div>
            <div className="content-check-form-multi-select">
              <SelectInputMulti
                label="Quality Dimensions"
                placeholder="Select"
                isSearchable
                hideChips
                value={contentCheckFilters.check_quality_dimension}
                onChange={(value) =>
                  setContentCheckFiltersState("check_quality_dimension", value)
                }
                enableOutsideScroll
                selectAll
                options={getFilterValues("check_quality_dimension")}
                data-testid="quality-dimension-filter"
              />
            </div>
            <div className="content-check-form-multi-select">
              <SelectInputMulti
                label="Criticality"
                placeholder="Select"
                isSearchable
                hideChips
                value={contentCheckFilters.check_criticality}
                onChange={(value) =>
                  setContentCheckFiltersState("check_criticality", value)
                }
                enableOutsideScroll
                selectAll
                options={getFilterValues("check_criticality")}
                data-testid="check_criticality-filter"
              />
            </div>
            <div className="content-check-form-multi-select">
              <SelectInputMulti
                label="Tags"
                placeholder="Select"
                isSearchable
                hideChips
                value={contentCheckFilters.check_tags}
                onChange={(value) =>
                  setContentCheckFiltersState("check_tags", value)
                }
                enableOutsideScroll
                selectAll
                options={getFilterValues("check_tags")}
                data-testid="tags-key-filter"
              />
            </div>
            <div className="content-check-bad-rows-filter">
              <TextInput
                placeholder="Enter Value"
                label="Bad Rows %"
                type="number"
                value={contentCheckFilters.bad_rows_from}
                onChange={(event) => {
                  setContentCheckFiltersState(
                    "bad_rows_from",
                    event.target.value
                  );
                }}
                data-testid="bad-rows-from-filter"
              />
              <span className="bad-rows-to-separator">to</span>
              <TextInput
                className="bad-rows-to-filter"
                placeholder="Enter keywords"
                label=""
                type="number"
                value={contentCheckFilters.bad_rows_to}
                onChange={(event) => {
                  setContentCheckFiltersState(
                    "bad_rows_to",
                    event.target.value
                  );
                }}
                data-testid="bad-rows-to-filter"
              />
            </div>
          </div>
          <div className="second-layer">
            <div className="content-check-core-filter">
              <RadioGroup
                size="sm"
                onChange={(e) =>
                  setContentCheckFiltersState("displayChecks", e.target.value)
                }
                value={contentCheckFilters.displayChecks}
                className="content-check-radio-group"
              >
                <RadioGroup.Radio
                  className="content-check-radio"
                  label="Show Anomaly + Core"
                  value="anomaly"
                />
                <RadioGroup.Radio
                  className="content-check-radio"
                  label="Show Only Core"
                  value="core"
                />
                <RadioGroup.Radio
                  className="content-check-radio"
                  label="Show All"
                  value="all"
                />
              </RadioGroup>
            </div>
            <div className="content-check-filter-buttons">
              <Button
                size="s"
                className="content-check-apply-button"
                onClick={() => applyFilters()}
                data-testid="content-check-filter-apply-btn"
              >
                Apply
              </Button>
              <Button
                size="s"
                className="apply-button"
                onClick={() => onReset()}
                variant="ghost"
                data-testid={"content-check-filter-reset-btn"}
              >
                Reset
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const config = {
    columns: [
      {
        label: "View Name",
        key: "view_name",
        sortColumn: true,
      },
      {
        label: "Check Count",
        key: "check_count",
        onRenderCell: (data) => renderCells("check_count", data),
        sortColumn: true,
      },
      {
        label: "Check Count With Bad Rows",
        key: "bad_rows_count",
        onRenderCell: (data) => renderCells("bad_rows_count", data),
        sortColumn: true,
      },
    ],
    sort: true,
  };
  const nestedConfig = {
    columns: [
      {
        label: "",
        key: "pin_icon",
        onRenderCell: (data) => renderCells("render_pin", data),
      },
      {
        label: "",
        key: "check_severity",
        onRenderCell: (data) => renderCells("check_severity", data),
      },
      getIsChecked(displayFields, "column_name")
        ? {
            label: "Column Name",
            key: "column_name",
            sortColumn: true,
            onRenderCell: (data) => renderCells("column_name", data),
          }
        : null,
      {
        label: "Check Name",
        key: "check_name",
        sortColumn: true,
        onRenderCell: (data) => renderCells("check_name", data),
      },
      getIsChecked(displayFields, "check_quality_dimension")
        ? {
            label: "Quality Dimensions",
            key: "check_quality_dimension",
            onRenderCell: (data) =>
              renderCells("check_quality_dimension", data),
          }
        : null,
      getIsChecked(displayFields, "tags")
        ? {
            label: "Tags",
            key: "tags",
            onRenderCell: (data) => renderCells("check_tags", data),
          }
        : null,
      getIsChecked(displayFields, "check_criticality")
        ? {
            label: "Criticality",
            key: "check_criticality",
            onRenderCell: (data) => renderCells("check_criticality", data),
          }
        : null,
      {
        label: "Total Rows",
        key: "total_rows",
        onRenderCell: (data) => renderCells("total_rows", data),
      },
      getIsChecked(displayFields, "clean_rows")
        ? {
            label: "Clean Rows",
            key: "clean_rows",
            onRenderCell: (data) => renderCells("clean_rows", data),
          }
        : null,
      {
        label: "Bad Rows",
        key: "bad_rows",
        onRenderCell: (data) => renderCells("bad_rows", data),
        sortColumn: true,
      },
      { label: "Threshold %", key: "threshold", sortColumn: true },
      {
        label: "% Bad-Clean Rows",
        key: "bad_row_percent",
        onRenderCell: (data) => renderCells("bad_row_percent", data),
        sortColumn: true,
      },
    ].filter(Boolean),
    caption: {
      headerText: "Details",
      headingLevel: "h3",
      descriptionText: " ",
    },
    nested: true,
  };

  const paginationConfig = {
    pageSize: 10,
    totalItemsCount: tableData?.length,
    enableGotoPage: true,
  };

  const expandableContent = {
    // getExpandButtonAriaLabel and getHideRowButtonAriaLabel are mandatory values for Table component configs.
    getExpandButtonAriaLabel: () => "",
    getHideRowButtonAriaLabel: () => "",
    rows: getExpandableRows(),
  };

  const exportToCsv = (isFiltered = false) => {
    let filtered_dataset_summary, filtered_dataset_check_summary;

    if (isFiltered) {
      ({ filtered_dataset_summary, filtered_dataset_check_summary } =
        applyFiltersCsv());
    } else {
      filtered_dataset_summary = contentChecks.dataset_summary;
      filtered_dataset_check_summary = contentChecks.dataset_check_summary;
    }
    const key = `${client}_${env}_${level}_${version}_${currentDataVersion}`;
    // pick only required fields which needs to be shown dataset_summary in excel
    const dataset_summary = filtered_dataset_summary.map(
      ({
        view_name,
        total_rows,
        bad_rows,
        clean_rows,
        bad_row_percent,
        accept,
      }) => {
        return {
          view_name,
          total_rows,
          bad_rows,
          clean_rows,
          bad_row_percent,
          accept,
        };
      }
    );
    generateAndDownloadCSV(dataset_summary, `${key}_dataset_summary.csv`);
    // pick only required fields which needs to be shown dataset_check_summary in excel
    /*eslint-disable*/
    const dataset_check_summary =
      filtered_dataset_check_summary.map(
        ({
          view_name,
          column_name,
          check_name,
          check_description,
          check_severity,
          check_criticality,
          check_quality_dimension,
          check_tags,
          is_core_check,
          total_rows,
          bad_rows,
          clean_rows,
          bad_row_percent,
          threshold,
          accept,
          check_remediation
        }) => {
          const check_tag = Object.keys(check_tags)
                              .map(tag => `${tag}:${check_tags[tag]}`)
                              .join(",");
          check_quality_dimension = check_quality_dimension.join(",");
          return {
            view_name,
            column_name,
            check_name,
            check_description,
            check_severity,
            check_criticality,
            check_quality_dimension,
            check_tag,
            is_core_check,
            total_rows,
            bad_rows,
            clean_rows,
            bad_row_percent,
            threshold,
            accept,
            check_remediation
          };
        }
      );
    generateAndDownloadCSV(
      dataset_check_summary,
      `${key}_dataset_check_summary.csv`
    );
  }

  return (
    <>
      {error && (
        <>
          {toast.show({
            title: toastConstants.CONTENT_CHECK_MISSING,
            type: toastConstants.ERROR,
          })}
        </>
      )}
      {isLoading && (
        <LoadingIndicator
          size={"l"}
          loading={isLoading}
          centerSpinner={true}
          displayOverlay={true}
          loadingText={"Loading..."}
          className="global-loading-indicator"
        />
      )}
      {!isLoading && !contentChecks && (
        <div className="no-records-message">
          <p>No records to show.</p>
        </div>
      )}
      {!isLoading && !error && contentChecks && (
        <div className="content-check-page" data-testid="content-check-page">
          {getContentCheckFilters()}
          <div className="content-check-table-message">
            {isTabletOrMobile && (
              <Tooltip
                content={
                  <>
                    {" "}
                    <InfoFilled className="table-info-icon" />
                    {constant.CONTENT_CHECK_TABLE_INFO}
                  </>
                }
                placement="bottom"
                className="client-details-tooltip"
              ></Tooltip>
            )}
            {!isTabletOrMobile && (
              <>
                <span>
                  <InfoFilled className="table-info-icon" />
                  {constant.CONTENT_CHECK_TABLE_INFO}
                </span>
              </>
            )}
            <div className="show-fields-badge">
              <Popover
                title=""
                content={fieldsOptions}
                open={displayShowFields}
                position="bottom"
                width={"300px"}
                onOpenChange={() => setDisplayShowFields(!displayShowFields)}
              >
                <Badge variant="info" outline className="show-badge">
                  <Icon
                    className="menu-icon"
                    src={menuIcon}
                    size={20}
                    color="rgb(140 190 255)"
                  ></Icon>
                  Show Fields
                </Badge>
              </Popover>
            </div>
            <div className="toggle-all-button">
              <Button
                size="s"
                onClick={() => {
                  setCollapseAll(!collapseAll);
                }}
              >
                {collapseAll ? "Expand All" : "Collapse All"}
              </Button>
            </div>
            <DropdownMenu
              style={{ borderRadius: "4px" }}
              label={constant.EXPORT_CSV}
              variant="filled"
              after={<IconSymbol icon="keyboard_arrow_down" />}
              menuItems={[
                {
                  title: 'Filtered Records',
                  onClick: () => {
                    exportToCsv(true);
                  },
                  icon: <IconSymbol icon="filter_alt"/>
                },
                {
                  title: 'All Records',
                  onClick: () => {
                    exportToCsv(false);
                  },
                  icon: <IconSymbol icon="download"/>
                },
              ]}
            />
          </div>
          <Pagination
            id="pagination-entries"
            config={paginationConfig}
            entriesPerPageConfig={entriesPerPageConfig}
            className={`${
              tableData.length === 0
                ? "no-pagination"
                : "pagination content-check-pagination"
            }`}
            onPageChange={onPageChange}
            page={page}
          >
            {({ pageSize }) => (
              <div className="content-check-table">
                <Table
                  data-testid="content-check-table"
                  className={"content-check-table"}
                  data={tableData}
                  config={config}
                  nestedConfig={nestedConfig}
                  expandableContent={expandableContent}
                  page={page}
                  pageSize={pageSize}
                />
                {tableData.length === 0 && (
                  <div className="no-records-message">
                    <p>No records to show.</p>
                  </div>
                )}
              </div>
            )}
          </Pagination>
        </div>
      )}
    </>
  );
}

ContentCheck.propTypes = {
  data: PropTypes.object,
  currentDataVersion: PropTypes.string,
};

export default ContentCheck;
