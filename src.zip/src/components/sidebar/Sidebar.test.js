import React from "react";
import { act, waitFor } from "@testing-library/react";
import { screen } from "@testing-library/react";
import { Toolkit } from "@uitk/react";

import "@testing-library/jest-dom";

import { renderWithProviders } from "../../test/test-utils";

import Sidebar from "./Sidebar";

let component = null;
beforeEach(async () => {
  await act(async () => {
    component = renderWithProviders(
      <Toolkit>
        <Sidebar />
      </Toolkit>
    );
  });
});

afterEach(() => {
  component.unmount();
});

describe("Renders Sidebar Component correctly", () => {
  test("Renders Sidebar Component correctly", async () => {
    await waitFor(() => {
      expect(screen.getByTestId("sidebar")).toBeInTheDocument();
    });
  });
});
