import { createServer } from "miragejs";

import { transformEvalChartsRespnse } from "./features/analyseChart/transformApiResponse";
import { getAppUrl } from "./utils/common";
import { constant } from "./utils/constants";
import analyseChartData from "./utils/mockdata/analyseChart";
import analyseChartEvalResult from "./utils/mockdata/analyseChartEvalResult";
import {
  clientDsIdFilter,
  ruleTypeFilter,
} from "./utils/mockdata/analyseChartRootFilters";
import contentCheckRecords from "./utils/mockdata/contentCheckMockdata.json";
import dashboardTableData from "./utils/mockdata/dashboardMockdata";
import evalRunDetails from "./utils/mockdata/evalReport";
import executionFailureMockdata from "./utils/mockdata/executionFailure.json";
import userMockData from "./utils/mockdata/userDetails";

export default function () {
  // Execution Failure Apis
  let evalFailures = executionFailureMockdata.eval_failures;
  createServer({
    routes() {
      this.urlPrefix = getAppUrl();

      this.get(`/eval_run/:id/${constant.EVAL_FAILURES}`, () => evalFailures);

      const logoutResponse = {
        logoutUrl: "/logout",
      };

      const isIdle = {
        isIdle: false,
      };
      const cdnUrl = {
        cdnUrl: "https://d1vvi2df1hxdp6.cloudfront.net",
      };

      // mocking get eval run details by eval run id
      this.get(`/${constant.EVAL_RUN}/:id`, () => evalRunDetails);
      this.get(`/content_check/:id`, () => {
        return contentCheckRecords;
      });
      this.get(`/dvp`, (schema, request) => {
        const evalType = request.queryParams.type;
        if (evalType === "eval_run") {
          return dashboardTableData;
        }
      });

      this.get(`/${constant.LOGOUT}`, () => logoutResponse);
      this.get(`/user`, () => userMockData);
      this.get(`/isidle`, () => isIdle);
      this.get(`/reportBaseUrl`, () => cdnUrl);
      this.patch(
        `/${constant.EVAL_FAILURES}/:id`,
        (schema, request) => {
          const attrs = JSON.parse(request.requestBody);
          const status = attrs.length > 1 ? 200 : 400;
          if (status === 200) {
            attrs.forEach((element) => {
              evalFailures = evalFailures.map((e) =>
                element.id === e.id
                  ? { ...e, failure_action: element.failure_action }
                  : e
              );
            });
          }
          return new Response(status, { some: "header" }, { some: ["data"] });
        },
        { timing: 2000 }
      );

      // Analyse charts Apis

      // get root filters
      this.get(
        `/${constant.EVAL_RUN}/:id/${constant.ROOT_FILTER}`,
        (schema, request) => {
          // hard coded id to establish both behaviour of root filters
          if (request.params.id === "app-20230720113010-0000_20230720124741") {
            return ruleTypeFilter;
          }
          return clientDsIdFilter;
        }
      );

      // get all filter values and charts
      this.post(
        `/${constant.EVAL_RUN}/:id/${constant.EVAL_RESULT}/search`,
        (_, request) => {
          const isMetadata = JSON.parse(request.requestBody)?.metadata;
          // return Eval Results to populate filters if metadata is true
          if (isMetadata) {
            return analyseChartEvalResult;
          }
          const page = JSON.parse(request.requestBody)?.page;
          const limit = JSON.parse(request.requestBody)?.limit;
          return {
            total: analyseChartData.total,
            eval_results: transformEvalChartsRespnse(
              analyseChartData.eval_results
            ).slice((page - 1) * 10, limit),
          };
        }
      );

      this.passthrough();
      this.passthrough(
        "https://maelstrom-dmz-nonprod.uhcprovider.com/cdn/abyss/**",
        "https://abyss-cloud.uhg.com/**"
      );
    },
  });
}
