const userMockData = {
  userName: "hjain18@optum.com",
  email: "hjain18@optum.com",
  userId: "00uns3kbfj7ch5NPf1t7",
  role: "InternalUser",
  firstName: "Hrishikesh",
  lastName: "Jain",
  accountType: "2",
};

export default userMockData;
