import React, { useEffect, useState } from "react";
import {
  Avatar,
  Button,
  Dialog,
  Header as SiteHeader,
  Text,
  Tooltip,
} from "@uitk/react";
import { Document, Guidelines, HelpHollow, Results } from "@uitk/react-icons";

import logo from "../../assets/logo.svg";
import { RoutableLink } from "../../utils/common";
import { constant } from "../../utils/constants";

import { useGetUserDetailsQuery, useLazyLogoutQuery } from "./HeaderApiSlice";

function Header() {
  const [logoutUser, results] = useLazyLogoutQuery();
  const { data: userDetails, isLoading } = useGetUserDetailsQuery();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const { data, isSuccess } = results;
    if (isSuccess) {
      window.location.href = data?.logoutUrl;
    }
  }, [results]);

  useEffect(() => {
    setInterval(() => {
      fetch("/api/isidle")
        .then((response) => response.json())
        .then((data) => {
          if (data.isIdle) {
            setOpen(true);
          }
        });
    }, 60000);
  }, []);

  const logoContent = (
    <>
      <div className="logocontent">
        <a href="/dashboard">
          <img
            loading="lazy"
            src={logo}
            className="logo"
            alt="logo with product name"
          />
        </a>
        <a className="logotext" href="/dashboard">
          <span></span>
          {constant.DATA_VALIDATION_PLATFORM}
        </a>
      </div>
    </>
  );

  const logout = () => {
    logoutUser();
  };

  const userInitials = () => {
    if (userDetails) {
      const { firstName, lastName } = userDetails;
      return `${firstName[0]}${lastName[0]}`;
    }
  };

  const globalNavigationConfigFunc = () => {
    return {
      linkAs: RoutableLink,
      links: [
        {
          label: "Overview",
          url: "/overview",
          icon: <Results customSize="24px" className="nav-icons" />,
        },
        {
          label: "Reports",
          url: "/dashboard",
          icon: <Results customSize="24px" className="nav-icons" />,
        },
        {
          label: "Help",
          icon: <HelpHollow customSize="24px" className="nav-icons" />,
          links: [
            {
              label: "About DVP",
              url: constant.DVP_DOCS_URL,
              target: "_blank",
              icon: <Guidelines customSize="24px" className="nav-icons" />,
              width: "70%",
            },
            {
              label: "User Guide",
              target: "_blank",
              url: constant.DVP_USER_GUIDE_URL,
              icon: <Document customSize="24px" className="nav-icons" />,
              width: "70%",
            },
          ],
        },
        {
          customContent: (
            <>
              <Tooltip content={userDetails?.userName} placement="bottom">
                <Avatar
                  className="header-avtar"
                  as={"span"}
                  initials={userInitials()}
                  backgroundColor="#002677"
                  size={"s"}
                  hideLabel
                />
              </Tooltip>
            </>
          ),
          links: [{ label: "Log out", onClick: logout }],
        },
      ],
    };
  };
  return (
    <>
      {!isLoading && (
        <>
          <div className="header">
            <SiteHeader
              className="header-container"
              globalNavigation={globalNavigationConfigFunc()}
              logoContent={logoContent}
            />
          </div>
        </>
      )}

      {open && (
        <Dialog
          title="Session Timeout"
          titleAs="h5"
          onClose={logout}
          closeButtonText="X"
          className="logout-modal"
        >
          <Dialog.Body>
            <Text>{constant.SESSION_EXPIRED_MESSAGE}</Text>
          </Dialog.Body>
          <Dialog.Actions>
            <div className="dialog_actions">
              <Button onPress={logout}>Logout</Button>
            </div>
          </Dialog.Actions>
        </Dialog>
      )}
    </>
  );
}

Header.propTypes = {};

export default Header;
