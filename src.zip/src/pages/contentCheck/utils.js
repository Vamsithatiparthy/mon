import React, { useEffect } from "react";
import { ProgressBar, Tooltip } from "@uitk/react";
import { WarningFilled } from "@uitk/react-icons";
import PropTypes from "prop-types";

import pinIcon from "../../assets/pinIcon.svg";
import { formatNumber, titleCase } from "../../utils/common";
import { constant } from "../../utils/constants";

const qdPopover = (check_quality_dimension) => {
  const qdCount = check_quality_dimension?.length;
  return (
    qdCount > 1 && (
      <>
        <Tooltip
          content={check_quality_dimension.slice(1).map((qd, index) => (
            <div key={index} className="quality-dimensions-popover-item">
              {titleCase(qd)}
            </div>
          ))}
        >
          {qdCount > 1 && (
            <div style={{ paddingLeft: "5px" }}>{`+${qdCount - 1}`}</div>
          )}
        </Tooltip>
      </>
    )
  );
};

const tagsPopover = (tags) => {
  const tagEntries = Object.entries(tags);
  const tagsCount = tagEntries.length;

  return (
    tagsCount > 1 && (
      <>
        <Tooltip
          content={tagEntries.slice(1).map(([key, value], index) => (
            <div key={`${index}-${key}`} className="tags-popover-item">
              {`${key}: ${value}`}
            </div>
          ))}
        >
          {tagsCount > 1 && (
            <div style={{ paddingLeft: "5px" }}>{`+${tagsCount - 1}`}</div>
          )}
        </Tooltip>
      </>
    )
  );
};

// add zoom class to progressbar to set width according to zoom
function addZoomClass(currentZoomLevel) {
  var progressBarElements = document.querySelectorAll(
    ".overlay div[class^='ProgressBarcomponent__ProgressBarContent']"
  );
  for (let i = 0; i < progressBarElements.length; i++) {
    let element = progressBarElements[i];
    Array.from(element.classList).forEach(function (className) {
      if (className.startsWith("zoom-")) {
        element.classList.remove(className);
      }
    });
  }
  for (let i = 0; i < progressBarElements.length; i++) {
    let element = progressBarElements[i];
    element.classList.add("zoom-" + currentZoomLevel);
  }
}

function getZoomLevel() {
  return Math.round(window.devicePixelRatio * 100) / 2;
}

const getProgressBarConfig = (bad_row_percent, clean_rows_percent) => {
  const customLabel = (
    <p className="bad-rows-percent-label">
      <span>{bad_row_percent.toFixed(2)}</span>
      <span>{clean_rows_percent.toFixed(2)}</span>
    </p>
  );
  return {
    label: customLabel,
    helperText: "",
    progress: bad_row_percent >= 70 ? bad_row_percent - 6 : bad_row_percent,
    initialLabel: customLabel,
    error: false,
  };
};

const getThresholdProgressBarConfig = (threshold) => {
  return {
    label: "",
    helperText: "",
    progress: threshold,
    error: false,
  };
};

function renderCells(key, data) {
  let {
    accept,
    view_name,
    check_count,
    check_name,
    column_name,
    is_core_check,
    check_severity,
    check_tags,
    bad_rows,
    bad_rows_count,
    total_rows,
    check_criticality,
    bad_row_percent,
    threshold,
    check_quality_dimension,
    clean_rows,
  } = data;
  switch (key) {
    case "view_name":
      return <span>{view_name}</span>;

    case "check_count":
      return (
        <span className={`${accept ? "" : "content-check-accept"}`}>
          {check_count}
        </span>
      );
    case "column_name":
      return column_name ? <span>{column_name}</span> : <span></span>;
    case "render_pin":
      return is_core_check ? (
        <Tooltip content={constant.CORE_RULES}>
          <div style={{ minWidth: "20px" }}>
            <img src={pinIcon} alt="core" height="20px" width="20px" />
          </div>
        </Tooltip>
      ) : (
        ""
      );
    case "check_name":
      return (
        <>
          <span style={{ wordWrap: "break-word" }}>{check_name}</span>
        </>
      );
    case "check_criticality":
      return check_criticality && check_criticality.length > 0 ? (
        <span>{titleCase(check_criticality)}</span>
      ) : (
        <span></span>
      );
    case "check_quality_dimension": {
      const qualityDimensions =
        check_quality_dimension.length !== 0 ? (
          <>
            {titleCase(check_quality_dimension[0])}
            {qdPopover(check_quality_dimension)}
          </>
        ) : (
          ""
        );

      return (
        <div className="quality-dimensions" style={{ display: "flex" }}>
          {qualityDimensions}
        </div>
      );
    }
    case "check_tags": {
      let tags_list = "";
      if (check_tags && Object.keys(check_tags).length > 0) {
        const [firstTagKey, firstTagValue] = Object.entries(check_tags)[0];
        const firstTag = `${firstTagKey}: ${firstTagValue}`;

        tags_list = (
          <>
            <span>{firstTag}</span>
            {tagsPopover(check_tags)}
          </>
        );
      }
      return (
        <div className="tags" style={{ display: "flex" }}>
          {tags_list}
        </div>
      );
    }

    case "total_rows":
      return <span>{formatNumber(total_rows)}</span>;

    case "clean_rows":
      return <span>{formatNumber(clean_rows)}</span>;

    case "bad_rows":
      return <span>{formatNumber(bad_rows)}</span>;

    case "bad_row_count":
      return <span>{formatNumber(bad_rows_count)}</span>;

    case "check_severity": {
      if (!accept) {
        const check_severity_btns = document.querySelectorAll(".anomaly");
        if (check_severity_btns.length > 0) {
          check_severity_btns.forEach((btn) => {
            const parentTd = btn.parentElement.parentElement;
            parentTd.classList.add("anomaly-severity");
          });
        }
      }
      return check_severity?.length > 0 ? (
        <Tooltip
          className={
            !accept ? "severity-icon-tooltip anomaly" : "severity-icon-tooltip"
          }
          content={check_severity}
        >
          <WarningFilled className="severity-icon" />
        </Tooltip>
      ) : (
        <span className={!accept ? "anomaly" : ""}></span>
      );
    }
    case "bad_row_percent": {
      const clean_rows_percent = 100 - bad_row_percent;
      threshold = threshold >= 70 ? threshold - 2 : threshold + 2;
      return (
        <BadRowPercentComponent
          bad_row_percent={bad_row_percent}
          clean_rows_percent={clean_rows_percent}
          threshold={threshold}
        />
      );
    }
  }
}

const BadRowPercentComponent = ({
  bad_row_percent,
  clean_rows_percent,
  threshold,
}) => {
  useEffect(() => {
    addZoomClass(getZoomLevel());
  }, []);
  return (
    <div className="container">
      <ProgressBar
        className={`bad-clean-percent background ${
          bad_row_percent == 0 ? "no-border " : ""
        }`}
        id="bad-rows-percent"
        config={getProgressBarConfig(bad_row_percent, clean_rows_percent)}
      />
      <ProgressBar
        className={`bad-clean-percent overlay ${
          bad_row_percent == 0 ? "no-border " : ""
        }`}
        id="bad-rows-percent"
        config={getThresholdProgressBarConfig(threshold)}
      />
    </div>
  );
};

BadRowPercentComponent.propTypes = {
  bad_row_percent: PropTypes.number.isRequired,
  clean_rows_percent: PropTypes.number.isRequired,
  threshold: PropTypes.number.isRequired,
};

const getIsChecked = (fields, field) => {
  const fieldObj = fields.find((f) => f.value === field);
  return fieldObj?.isChecked;
};

const checkboxes = [
  {
    label: "Check Name",
    value: "check_name",
    isChecked: true,
    isDisabled: true,
  },
  {
    label: "Total Rows",
    value: "total_rows",
    isChecked: true,
    isDisabled: true,
  },
  { label: "Bad rows", value: "bad_rows", isChecked: true, isDisabled: true },
  {
    label: "Bad-Clean-Rows",
    value: "bad_clean_rows",
    isChecked: true,
    isDisabled: true,
  },
  {
    label: "Threshold",
    value: "threshold",
    isChecked: true,
    isDisabled: true,
  },
  {
    label: "Clean Rows",
    value: "clean_rows",
    isChecked: false,
    isDisabled: false,
  },
  {
    label: "Column Name",
    value: "column_name",
    isChecked: false,
    isDisabled: false,
  },
  {
    label: "Quality Dimensions",
    value: "check_quality_dimension",
    isChecked: false,
    isDisabled: false,
  },
  {
    label: "Criticality",
    value: "check_criticality",
    isChecked: false,
    isDisabled: false,
  },
  {
    label: "Tags",
    value: "tags",
    isChecked: false,
    isDisabled: false,
  },
];

const entriesPerPageConfig = {
  pageSizeOptions: [
    {
      label: "10",
      value: 10,
    },
    {
      label: "50",
      value: 50,
    },
    {
      label: "100",
      value: 100,
    },
  ],
  initialValue: 10,
};

export {
  addZoomClass,
  checkboxes,
  entriesPerPageConfig,
  getIsChecked,
  getZoomLevel,
  renderCells,
};
