import { apiSlice } from "../../app/apiSlice";
import { sort } from "../../utils/common";
import { constant } from "../../utils/constants";

export const evalReportApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getExecutionFailures: builder.query({
      query: (id) => `/eval_run/${id}/${constant.EVAL_FAILURES}`,
      transformResponse: (response) => {
        const evalFailures = response.map((obj) => {
          const failure_action = obj.failure_action;
          return {
            ...obj,
            checked: false,
            updated: failure_action == null && obj?.is_recurring, // This logic is wrong, need to revisit
            failure_action:
              failure_action == null && obj.is_recurring
                ? constant.IGNORED
                : failure_action,
            error: false,
            column: String(obj.column),
          };
        });

        return sort(evalFailures, "is_recurring", -1);
      },
      providesTags: ["EvalFailure"],
    }),
    getEvalRunById: builder.query({
      query: (id) => `${constant.EVAL_RUN}/${id}`,
    }),
    getReportBaseUrl: builder.query({
      query: () => `reportBaseUrl`,
    }),
    updateExecutionFailures: builder.mutation({
      query(data) {
        const { evalID, updatedEvalFailures } = data;
        return {
          url: `/eval_run/${evalID}/${constant.EVAL_FAILURES}`,
          method: "PATCH",
          body: updatedEvalFailures,
        };
      },
      invalidatesTags: ["EvalFailure"],
    }),
    setQcStatus: builder.mutation({
      query(data) {
        const { dvp_run_id, qcStatus } = data;
        return {
          url: `/approval/${dvp_run_id}`,
          method: "PATCH",
          body: qcStatus,
        };
      },
    }),
  }),
});

export const {
  useGetExecutionFailuresQuery,
  useUpdateExecutionFailuresMutation,
  useGetEvalRunByIdQuery,
  useGetReportBaseUrlQuery,
  useSetQcStatusMutation,
} = evalReportApiSlice;
