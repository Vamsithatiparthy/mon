import { StepIndicator } from "@abyss/web/ui/StepIndicator";
import PropTypes from "prop-types";
function ProgressWizard({ currentStep, steps, onClick }) {
  return (
    <div className="col">
      <StepIndicator currentStep={currentStep} barColor={"#CCCCCC"}>
        {steps.map((element, index) => {
          return (
            <StepIndicator.Step
              key={index}
              className={`${currentStep == index + 1 ? "active " : ""}${
                currentStep > index + 1 ? "completed" : ""
              }`}
              label={element}
              onClick={() => onClick(currentStep, index + 1)}
            />
          );
        })}
      </StepIndicator>
    </div>
  );
}

ProgressWizard.propTypes = {
  steps: PropTypes.arrayOf(String),
  currentStep: PropTypes.number,
  onClick: PropTypes.func,
};

export default ProgressWizard;
