import React from "react";
import { useDispatch } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";

import Header from "./components/header/Header";
import SiteFooter from "./components/siteFooter/SiteFooter";
import { setActionBtnHeight } from "./features/executionFailure/evalFailuresSlice";
import Routes from "./routes/routes/routes";
import userMockData from "./utils/mockdata/userDetails";

import "./styles/scss/App.scss";

function App() {
  const dispatch = useDispatch();
  const handleScroll = (event) => {
    dispatch(setActionBtnHeight(event.currentTarget.scrollTop));
  };
  // This on click is creating issues with selct checkbox, this functionality needs to be investigated and added later
  // const handleOnclick = (e) => {
  //   dispatch(setReasonTooltipVisbility(e.target.id));
  // };

  const loader = document.getElementById("inital-loader");
  if (loader) {
    loader.remove();
  }

  return (
    <Router getUserConfirmation={() => {}}>
      <div className="main">
        <Header userDetails={userMockData} />
        <div className="app-container">
          <div className="containerFlex">
            <div className="right_container" onScroll={(e) => handleScroll(e)}>
              <Routes />
              <SiteFooter />
            </div>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
