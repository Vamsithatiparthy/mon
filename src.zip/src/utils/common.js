import { Link } from "react-router-dom";
import { anchorProperties, getNativeProps } from "@uitk/react";
import Papa from "papaparse";

const APP_BASE_URL = "http://localhost:3000/api";
const RoutableLink = (item) => {
  const { children, url } = item;
  const anchorProps = getNativeProps(item, anchorProperties);

  return (
    <Link {...anchorProps} to={url}>
      {children}
    </Link>
  );
};

// This function count the records for a given key, records should be object array ,sample output
// Output: { 21: 3, 22: 1, 23: 1 }
function countRecords(records, key, initialRecords = [], sort = false) {
  const counts = new Map();
  initialRecords.forEach((element) => {
    counts.set(element?.key, element?.value);
  });

  for (const record of records) {
    if (key in record) {
      const value = record[key];
      if (counts.has(value)) {
        counts.set(value, counts.get(value) + 1);
      } else {
        counts.set(value, 1);
      }
    }
  }

  if (sort) {
    const sortedArray = Array.from(counts).sort(function (a, b) {
      return a[0] - b[0];
    });
    const sortedResults = new Map(sortedArray);
    return Object.fromEntries(sortedResults);
  }

  return Object.fromEntries(counts);
}

const containsString = (array, str) => {
  let isPresent = false;
  array.forEach((element) => {
    if (
      element.toString().toLowerCase() === str?.toString()?.toLowerCase().trim()
    ) {
      isPresent = true;
    }
  });
  return isPresent;
};

const sort = (arr, key, sortDirection) => {
  const newArr = [...arr];
  newArr.sort(function (a, b) {
    if (a[key] < b[key]) {
      return sortDirection;
    }
    if (a[key] > b[key]) {
      return -sortDirection;
    }
    return 0;
  });
  return newArr;
};
/**
 * This method takes object array and value array as param and returns the index of object
 * which contains all of the values of value array.
 */

// created this function to reduce parent function cognitive complexity
const getFilteredRecords = (filterName, filters, data) => {
  if (!data) return [];
  /* First we are filtering the data based on the current filters applied */
  /* We are looping through the data and checking every filters with every element */
  return data.filter((element) => {
    return Object.keys(filters).every((key) => {
      if (key === filterName) {
        return true;
      }
      if (key === "check_tags") {
        if (filters[key]?.length === 0) {
          return true;
        }
        filters[key].every((tag) => {
          tag = JSON.parse(tag);
          return Object.entries(tag).every(([k, v]) => {
            return element[key][k] === v;
          });
        });
      }
      if (typeof filters[key] == "boolean") {
        if (filters[key]) {
          return !element["is_recurring"];
        }
        return true;
      } else {
        return (
          filters[key]?.length === 0 ||
          containsString(filters[key], element[key])
        );
      }
    });
  });
};

const getAppUrl = () => {
  if (process.env.NODE_ENV === "local") {
    return APP_BASE_URL;
  }
  const domainAPIName =
    window.location.protocol + "//" + window.location.host + "/api";
  return domainAPIName;
};

// This fuction use to generate and download the csv file
function generateAndDownloadCSV(csvData, fileName) {
  const csv = Papa.unparse(csvData);

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });

  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", fileName);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

const convertToSnakeCase = (str) => {
  return str
    .split(/(?=[A-Z])/)
    .join("_")
    .toLowerCase();
};

function changeKeyName(obj) {
  return Object.keys(obj).reduce((acc, key) => {
    const newKey = convertToSnakeCase(key) || key;
    acc[newKey] = obj[key];
    return acc;
  }, {});
}

const getFilterOptions = (filterName, currentFilters, data) => {
  // create a filter object which will contain currentFilters upto that filter only
  let filters = {};
  const filterNames = Object.keys(currentFilters);
  for (const key of filterNames) {
    if (key === filterName) {
      break;
    }
    filters[key] = currentFilters[key];
  }

  const filterSet = new Set();
  const filteredRecords = getFilteredRecords(filterName, filters, data);
  const options = filteredRecords.reduce((acc, element) => {
    if (element[filterName] != "" && !filterSet.has(element[filterName])) {
      filterSet.add(element[filterName]);
      if (Array.isArray(element[filterName])) {
        element[filterName].forEach((value) => {
          if (value === null) return;
          acc.push({
            value: String(value),
            label: titleCase(value),
          });
        });
      } else if (
        typeof element[filterName] === "object" &&
        element[filterName] !== null
      ) {
        const keys = Object.keys(element[filterName]);
        if (!keys || keys.length === 0) return acc;
        keys.forEach((key) => {
          acc.push({
            value: JSON.stringify({ [key]: element[filterName][key] }), // stringify the object to use as value
            label: `${key}: ${element[filterName][key]}`,
          });
        });
      } else {
        if (element[filterName] === null) return acc;
        acc.push({
          value: String(element[filterName]),
          label: titleCase(element[filterName]),
        });
      }
    }
    return acc;
  }, []);
  // remove duplicate options
  const uniqueOptions = (() => {
    if (options === null) return [];

    const labelsSet = new Set();
    const uniqueOptionsArray = [];

    options.forEach((option) => {
      if (!labelsSet.has(option.label)) {
        labelsSet.add(option.label);
        uniqueOptionsArray.push(option);
      }
    });

    return uniqueOptionsArray;
  })();

  return uniqueOptions;
};

// convert to camel case
function camelCase(str) {
  if (str)
    return str
      .replace(/\s(.)/g, function (a) {
        return a.toUpperCase();
      })
      .replace(/\s/g, "")
      .replace(/^(.)/, function (b) {
        return b.toLowerCase();
      });
}

// convert to title case
function titleCase(str) {
  str = str.replace(/["']/g, "");
  return str.replace(/\w\S*/g, function (txt) {
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
  });
}

// format date with local timezone
function formatDateTime(date) {
  const utc_time = new Date(date + " UTC");

  const formatted_time = utc_time.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZoneName: "short",
  });
  const formatted_date = utc_time.toLocaleDateString("en-GB", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  return `${formatted_date}, ${formatted_time}`;
}

// format number in international format
function formatNumber(input) {
  const number = typeof input === "string" ? parseFloat(input) : input;
  if (isNaN(number)) {
    return input; // Return the input if it's not a valid number
  }
  return new Intl.NumberFormat("en-US").format(number);
}

function filterDataPoints(chart_value, table_content) {
  // handle empty or missing chart data
  if (!chart_value?.length || !table_content?.length) {
    return {
      filteredChartValue: chart_value,
      filteredTableContent: table_content,
    };
  }

  const buildValues = chart_value.filter((item) =>
    ["Previous Build Value", "Current Build Value"].includes(item.name)
  );

  if (buildValues.length !== 2 || !buildValues[0]?.y || !buildValues[1]?.y) {
    return {
      filteredChartValue: chart_value,
      filteredTableContent: table_content,
    };
  }

  // Find first index where both build values have non-zero values
  const firstNonZeroIndex = buildValues[0].y.findIndex(
    (_, i) => buildValues[0].y[i] !== 0 || buildValues[1].y[i] !== 0
  );

  // Apply filtering
  const filteredChartValue = chart_value.map((chart) => ({
    ...chart,
    text: firstNonZeroIndex !== -1 ? chart.text?.slice(firstNonZeroIndex) : [],
    x: firstNonZeroIndex !== -1 ? chart.x?.slice(firstNonZeroIndex) : [],
    y: firstNonZeroIndex !== -1 ? chart.y?.slice(firstNonZeroIndex) : [],
  }));

  const filteredTableContent = Array.isArray(table_content)
    ? firstNonZeroIndex !== -1
      ? table_content.slice(firstNonZeroIndex)
      : []
    : table_content;

  return {
    filteredChartValue,
    filteredTableContent,
  };
}

export {
  camelCase,
  changeKeyName,
  containsString,
  countRecords,
  filterDataPoints,
  formatDateTime,
  formatNumber,
  generateAndDownloadCSV,
  getAppUrl,
  getFilterOptions,
  RoutableLink,
  sort,
  titleCase,
};
